# Jogo de Corrida Distribuído

Jogo de corrida multiplayer online com arquitetura distribuída. Múltiplos servidores formam um cluster, elegem um líder pelo algoritmo Bully, sincronizam estado via relógio lógico de Lamport e se comunicam por um protocolo RPC próprio sobre TCP. O cliente usa Pygame.

---

## Instalação

```bash
pip install pygame
```

Python 3.10+. Sem outras dependências externas.

---

## Modos de execução

### Servidor / nó distribuído

```bash
python test.py server --port 7001
```

| Parâmetro | Descrição                                                         | Padrão    |
| --------- | ----------------------------------------------------------------- | --------- |
| `--port`  | Porta TCP de escuta                                               | `7001`    |
| `--host`  | Interface de rede                                                 | `0.0.0.0` |
| `--id`    | ID numérico do nó (gerado automaticamente se omitido)             | auto      |
| `--peer`  | Endereço de outro nó: `host:porta` ou `id:host:porta` (repetível) | —         |

> `server` e `node` são equivalentes.

### Cliente (Pygame)

```bash
python test.py client --player MeuNome --server 127.0.0.1:7001
```

| Parâmetro  | Descrição                     | Padrão                   |
| ---------- | ----------------------------- | ------------------------ |
| `--player` | Nome do jogador               | `player-XXX` (aleatório) |
| `--server` | Endereço inicial `host:porta` | `127.0.0.1:7001`         |

### Modo local (sem rede)

```bash
python test.py local --player MeuNome
```

Roda só a física, sem nenhuma rede. Útil para testar o jogo isolado.

---

## Exemplos

### Um único servidor

```bash
# Terminal 1
python test.py server --port 7001

# Terminal 2
python test.py client --player Alice --server 127.0.0.1:7001
```

### Cluster local com dois nós

```bash
# Terminal 1 — nó com ID maior vira líder
python test.py server --id 10 --port 7001

# Terminal 2 — conecta ao primeiro como peer
python test.py server --id 5 --port 7002 --peer 127.0.0.1:7001

# Terminal 3 — cliente (pode apontar para qualquer nó)
python test.py client --player Alice --server 127.0.0.1:7001
```

### Cluster em rede local (máquinas diferentes)

```bash
# Máquina A (192.168.1.10)
python test.py server --id 10 --port 7001

# Máquina B (192.168.1.11)
python test.py server --id 5 --port 7001 --peer 192.168.1.10:7001

# Cliente em qualquer máquina
python test.py client --player Bob --server 192.168.1.10:7001
```

---

## Controles

| Tecla         | Ação                                 |
| ------------- | ------------------------------------ |
| `W` / `↑`     | Direcionar para cima                 |
| `S` / `↓`     | Direcionar para baixo                |
| `A` / `←`     | Direcionar para esquerda             |
| `D` / `→`     | Direcionar para direita              |
| `X` / `Enter` | Acelerar                             |
| `Shift`       | Drift                                |
| `R`           | Boost                                |
| `G`           | Debug (mostra vetores de velocidade) |

---

## Comportamento do cluster

- O nó com **maior ID** vence a eleição e vira líder.
- O líder processa inputs e replica o estado do jogo para os outros nós ~15x por segundo.
- Se o líder cair, os seguidores detectam em ~0,5 s e iniciam nova eleição automaticamente.
- O cliente descobre o novo líder via campo `redirect` nas respostas e reconecta sem intervenção manual.
- Nós com falha ficam em cooldown de 3 s antes de nova tentativa de contato.