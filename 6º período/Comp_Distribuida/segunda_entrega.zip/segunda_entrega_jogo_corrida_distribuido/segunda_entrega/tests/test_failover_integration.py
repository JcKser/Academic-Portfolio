import json
import socket
import subprocess
import sys
import time
import unittest
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, Optional


APP = Path(__file__).resolve().parents[1] / "distributed_racing.py"


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def rpc(
    port: int,
    method: str = "status",
    params: Optional[Dict[str, Any]] = None,
    timeout: float = 1.0,
) -> Dict[str, Any]:
    request_id = str(uuid.uuid4())
    message = {
        "type": "request",
        "id": request_id,
        "sender": "integration-test",
        "clock": 1,
        "method": method,
        "params": params or {},
    }
    with socket.create_connection(("127.0.0.1", port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        sock.sendall((json.dumps(message) + "\n").encode("utf-8"))
        data = bytearray()
        while not data.endswith(b"\n"):
            chunk = sock.recv(65536)
            if not chunk:
                break
            data.extend(chunk)
    response = json.loads(data.decode("utf-8"))
    if response.get("error"):
        raise RuntimeError(response["error"])
    return response["result"]


def wait_for(
    port: int,
    predicate: Callable[[Dict[str, Any]], bool],
    timeout: float = 8.0,
) -> Dict[str, Any]:
    deadline = time.monotonic() + timeout
    last_error: Optional[Exception] = None
    while time.monotonic() < deadline:
        try:
            result = rpc(port)
            if predicate(result):
                return result
        except Exception as exc:  # processo pode ainda estar inicializando
            last_error = exc
        time.sleep(0.05)
    raise AssertionError(f"condição não atingida na porta {port}: {last_error}")


class FailoverIntegrationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.processes: list[subprocess.Popen[Any]] = []
        self.high_port = free_port()
        self.low_port = free_port()

    def tearDown(self) -> None:
        for process in self.processes:
            if process.poll() is None:
                process.terminate()
        for process in self.processes:
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)

    def start_node(self, node_id: int, port: int, peer: Optional[str] = None) -> subprocess.Popen[Any]:
        command = [
            sys.executable,
            str(APP),
            "server",
            "--host",
            "127.0.0.1",
            "--id",
            str(node_id),
            "--port",
            str(port),
        ]
        if peer:
            command.extend(["--peer", peer])
        process = subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        self.processes.append(process)
        return process

    def test_early_replication_failover_and_rejoin_preserve_state(self) -> None:
        old_leader = self.start_node(10, self.high_port)
        wait_for(self.high_port, lambda status: status["leader_id"] == 10)

        self.start_node(5, self.low_port, f"10:127.0.0.1:{self.high_port}")
        wait_for(self.low_port, lambda status: status["leader_id"] == 10)

        joined = rpc(
            self.high_port,
            "join_player",
            {"player_id": "alice", "color": [20, 40, 60]},
        )
        self.assertEqual(joined["replication"]["acked_replicas"], 1)
        self.assertFalse(joined["replication"]["degraded"])

        follower = wait_for(
            self.low_port,
            lambda status: any(
                player["player_id"] == "alice"
                for player in status["snapshot"]["players"]
            ),
            timeout=2,
        )
        old_term = follower["leader_term"]

        old_leader.terminate()
        old_leader.wait(timeout=3)
        promoted = wait_for(
            self.low_port,
            lambda status: status["leader_id"] == 5,
            timeout=8,
        )

        self.assertGreater(promoted["leader_term"], old_term)
        self.assertIn(
            "alice", {player["player_id"] for player in promoted["snapshot"]["players"]}
        )
        self.assertIsNotNone(promoted["metrics"]["last_failover_seconds"])

        restarted_high = self.start_node(
            10, self.high_port, f"5:127.0.0.1:{self.low_port}"
        )
        recovered = wait_for(
            self.high_port,
            lambda status: status["leader_id"] == 10
            and any(
                player["player_id"] == "alice"
                for player in status["snapshot"]["players"]
            ),
            timeout=8,
        )
        self.assertGreater(recovered["leader_term"], promoted["leader_term"])
        self.assertIsNone(restarted_high.poll())


if __name__ == "__main__":
    unittest.main()
