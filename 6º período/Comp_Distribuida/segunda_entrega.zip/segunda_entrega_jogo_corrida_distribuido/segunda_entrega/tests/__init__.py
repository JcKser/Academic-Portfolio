"""Testes automatizados do jogo de corrida distribuído."""
