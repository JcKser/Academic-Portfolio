import copy
import unittest

from distributed_racing import DistributedGameNode, GameWorld, LamportClock


class LamportClockTests(unittest.TestCase):
    def test_tick_and_observe_follow_lamport_rules(self) -> None:
        clock = LamportClock()

        self.assertEqual(clock.tick(), 1)
        self.assertEqual(clock.observe(8), 9)
        self.assertEqual(clock.observe(3), 10)


class SnapshotOrderingTests(unittest.TestCase):
    def test_newer_term_is_accepted_even_after_leadership_change(self) -> None:
        source = GameWorld()
        source.add_player("alice", (1, 2, 3))
        snapshot = source.snapshot(10, logical_clock=7, leader_term=2)
        follower = GameWorld()

        accepted, reason = follower.load_snapshot(snapshot)

        self.assertTrue(accepted)
        self.assertEqual(reason, "applied")
        self.assertEqual(follower.leader_term, 2)
        self.assertIn("alice", follower.players)

    def test_stale_term_and_stale_version_are_rejected(self) -> None:
        world = GameWorld()
        world.version = 20
        world.leader_term = 4

        stale_term = {
            "leader_id": 10,
            "leader_term": 3,
            "logical_clock": 99,
            "version": 100,
            "players": [],
        }
        stale_version = copy.deepcopy(stale_term)
        stale_version.update({"leader_term": 4, "version": 19})

        self.assertEqual(world.load_snapshot(stale_term), (False, "stale_term"))
        self.assertEqual(world.load_snapshot(stale_version), (False, "stale_version"))


class ProtocolValidationTests(unittest.TestCase):
    def test_snapshot_must_declare_a_valid_leader(self) -> None:
        source = GameWorld()
        source.add_player("alice", (1, 2, 3))
        snapshot = source.snapshot(10, logical_clock=5, leader_term=2)
        snapshot["leader_id"] = -1
        follower = DistributedGameNode(5, "127.0.0.1", 19005, [])

        result = follower.replicate_snapshot({"snapshot": snapshot})

        self.assertFalse(result["accepted"])
        self.assertEqual(result["reason"], "invalid_leader")
        self.assertNotIn("alice", follower.world.players)

    def test_stale_coordinator_is_rejected(self) -> None:
        node = DistributedGameNode(5, "127.0.0.1", 19005, [])
        node.current_term = 8
        node.leader_id = 10

        result = node.receive_coordinator(
            {"leader_id": 7, "term": 6, "port": 19007}, "127.0.0.1"
        )

        self.assertFalse(result["accepted"])
        self.assertEqual(node.current_term, 8)
        self.assertEqual(node.leader_id, 10)


if __name__ == "__main__":
    unittest.main()
