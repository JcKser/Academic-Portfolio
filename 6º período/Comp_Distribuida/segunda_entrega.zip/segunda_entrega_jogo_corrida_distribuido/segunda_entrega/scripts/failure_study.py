"""Executa ensaios repetíveis de replicação e failover em localhost.

O estudo cria dois processos servidores, confirma a replicação da entrada de um
jogador, encerra abruptamente o líder e mede o tempo até o seguidor responder
como novo líder preservando o estado. O resultado pode ser salvo em JSON e em
Markdown para uso no relatório técnico.
"""

import argparse
import json
import socket
import subprocess
import sys
import time
import uuid
from pathlib import Path
from statistics import mean, median
from typing import Any, Callable, Dict, Optional


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "distributed_racing.py"


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def rpc(
    port: int,
    method: str = "status",
    params: Optional[Dict[str, Any]] = None,
    timeout: float = 1.0,
) -> Dict[str, Any]:
    request_id = str(uuid.uuid4())
    message = {
        "type": "request",
        "id": request_id,
        "sender": "failure-study",
        "clock": 1,
        "method": method,
        "params": params or {},
    }
    with socket.create_connection(("127.0.0.1", port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        sock.sendall((json.dumps(message) + "\n").encode("utf-8"))
        data = bytearray()
        while not data.endswith(b"\n"):
            chunk = sock.recv(65536)
            if not chunk:
                break
            data.extend(chunk)
    response = json.loads(data.decode("utf-8"))
    if response.get("error"):
        raise RuntimeError(response["error"])
    return response["result"]


def wait_for(
    port: int,
    predicate: Callable[[Dict[str, Any]], bool],
    timeout: float = 10.0,
) -> Dict[str, Any]:
    deadline = time.monotonic() + timeout
    last_error: Optional[Exception] = None
    while time.monotonic() < deadline:
        try:
            result = rpc(port)
            if predicate(result):
                return result
        except Exception as exc:
            last_error = exc
        time.sleep(0.04)
    raise TimeoutError(f"condição não atingida na porta {port}: {last_error}")


def start_node(node_id: int, port: int, peer: Optional[str] = None) -> subprocess.Popen[Any]:
    command = [
        sys.executable,
        str(APP),
        "server",
        "--host",
        "127.0.0.1",
        "--id",
        str(node_id),
        "--port",
        str(port),
    ]
    if peer:
        command.extend(["--peer", peer])
    return subprocess.Popen(
        command,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def stop_process(process: subprocess.Popen[Any]) -> None:
    if process.poll() is None:
        process.terminate()
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=2)


def crash_process(process: subprocess.Popen[Any]) -> None:
    """Injeta uma falha crash-stop sem aguardar encerramento gracioso."""
    if process.poll() is None:
        process.kill()
    process.wait(timeout=2)


def run_trial(number: int) -> Dict[str, Any]:
    high_port = free_port()
    low_port = free_port()
    processes: list[subprocess.Popen[Any]] = []
    try:
        leader = start_node(10, high_port)
        processes.append(leader)
        wait_for(high_port, lambda status: status["leader_id"] == 10)

        follower = start_node(5, low_port, f"10:127.0.0.1:{high_port}")
        processes.append(follower)
        follower_before = wait_for(
            low_port, lambda status: status["leader_id"] == 10
        )

        replication_started = time.monotonic()
        joined = rpc(
            high_port,
            "join_player",
            {"player_id": f"study-player-{number}", "color": [40, 120, 220]},
        )
        replication_seconds = time.monotonic() - replication_started
        expected_player = f"study-player-{number}"
        replicated = wait_for(
            low_port,
            lambda status: any(
                player["player_id"] == expected_player
                for player in status["snapshot"]["players"]
            ),
            timeout=2,
        )

        old_term = int(replicated["leader_term"])
        failure_started = time.monotonic()
        crash_process(leader)
        promoted = wait_for(
            low_port, lambda status: status["leader_id"] == 5, timeout=10
        )
        failover_seconds = time.monotonic() - failure_started
        preserved = any(
            player["player_id"] == expected_player
            for player in promoted["snapshot"]["players"]
        )

        return {
            "trial": number,
            "replication_seconds": round(replication_seconds, 4),
            "join_acked_replicas": int(
                joined.get("replication", {}).get("acked_replicas", 0)
            ),
            "failover_seconds": round(failover_seconds, 4),
            "term_before": old_term,
            "term_after": int(promoted["leader_term"]),
            "state_preserved": preserved,
            "new_leader": int(promoted["leader_id"]),
            "passed": preserved
            and int(promoted["leader_id"]) == 5
            and int(promoted["leader_term"]) > old_term,
            "watchdog_failures_before_election": 3,
            "initial_follower_term": int(follower_before["leader_term"]),
        }
    finally:
        for process in processes:
            stop_process(process)


def summarize(trials: list[Dict[str, Any]]) -> Dict[str, Any]:
    replication = [float(trial["replication_seconds"]) for trial in trials]
    failover = [float(trial["failover_seconds"]) for trial in trials]
    return {
        "trials": len(trials),
        "passed": sum(bool(trial["passed"]) for trial in trials),
        "state_preserved": sum(bool(trial["state_preserved"]) for trial in trials),
        "replication_seconds": {
            "min": round(min(replication), 4),
            "mean": round(mean(replication), 4),
            "median": round(median(replication), 4),
            "max": round(max(replication), 4),
        },
        "failover_seconds": {
            "min": round(min(failover), 4),
            "mean": round(mean(failover), 4),
            "median": round(median(failover), 4),
            "max": round(max(failover), 4),
        },
    }


def markdown_report(payload: Dict[str, Any]) -> str:
    lines = [
        "# Resultados do estudo de falhas",
        "",
        "Ambiente: dois processos Python em `localhost`, líder de ID 10 e réplica de ID 5.",
        "A falha é injetada encerrando o processo líder após a confirmação da réplica.",
        "",
        "| Ensaio | ACKs | Replicação (s) | Failover (s) | Estado preservado | Resultado |",
        "|---:|---:|---:|---:|:---:|:---:|",
    ]
    for trial in payload["results"]:
        lines.append(
            f"| {trial['trial']} | {trial['join_acked_replicas']} | "
            f"{trial['replication_seconds']:.4f} | {trial['failover_seconds']:.4f} | "
            f"{'sim' if trial['state_preserved'] else 'não'} | "
            f"{'passou' if trial['passed'] else 'falhou'} |"
        )
    summary = payload["summary"]
    lines.extend(
        [
            "",
            "## Resumo",
            "",
            f"- Ensaios aprovados: {summary['passed']}/{summary['trials']}.",
            f"- Estado preservado: {summary['state_preserved']}/{summary['trials']}.",
            f"- Replicação média: {summary['replication_seconds']['mean']:.4f} s.",
            f"- Failover médio: {summary['failover_seconds']['mean']:.4f} s.",
            f"- Faixa de failover: {summary['failover_seconds']['min']:.4f} a "
            f"{summary['failover_seconds']['max']:.4f} s.",
            "",
            "Os números medem execução local e não devem ser generalizados para uma rede real. "
            "Em máquinas distintas, latência, perda de pacotes e agendamento do sistema operacional "
            "podem alterar os tempos.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Estudo repetível de replicação e failover")
    parser.add_argument("--trials", type=int, default=5, help="quantidade de ensaios")
    parser.add_argument("--json-output", type=Path, default=None)
    parser.add_argument("--markdown-output", type=Path, default=None)
    args = parser.parse_args()
    if args.trials < 1:
        parser.error("--trials deve ser maior que zero")

    results = [run_trial(index) for index in range(1, args.trials + 1)]
    payload = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "python": sys.version.split()[0],
        "environment": "localhost / dois processos / TCP",
        "results": results,
        "summary": summarize(results),
    }
    rendered_json = json.dumps(payload, ensure_ascii=False, indent=2)
    print(rendered_json)
    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        args.json_output.write_text(rendered_json + "\n", encoding="utf-8")
    if args.markdown_output:
        args.markdown_output.parent.mkdir(parents=True, exist_ok=True)
        args.markdown_output.write_text(markdown_report(payload), encoding="utf-8")


if __name__ == "__main__":
    main()
