# Jogo de Corrida Distribuído

Jogo multiplayer com arquitetura primário-réplica. Os nós elegem o líder pelo algoritmo Bully, ordenam eventos com relógios lógicos de Lamport e replicam o estado usando termos de liderança, versões monotônicas e confirmações das réplicas.

O material original foi preservado em [`primeira_entrega/`](primeira_entrega/). A explicação técnica completa da evolução está em [`docs/DOCUMENTACAO_TECNICA.md`](docs/DOCUMENTACAO_TECNICA.md).

## Requisitos

- Python 3.10 ou superior.
- Pygame 2.5 ou superior, necessário apenas para o cliente gráfico.
- Máquinas na mesma rede local ou VPN, com as portas TCP escolhidas liberadas.

```bash
python -m pip install -r requirements.txt
```

## Execução rápida

Abra três terminais no diretório do projeto.

```bash
# Terminal 1: nó de maior ID, líder inicial
python distributed_racing.py server --host 0.0.0.0 --id 10 --port 7001

# Terminal 2: réplica
python distributed_racing.py server --host 0.0.0.0 --id 5 --port 7002 --peer 10:127.0.0.1:7001

# Terminal 3: cliente
python distributed_racing.py client --player Alice --server 127.0.0.1:7001
```

`server` e `node` são equivalentes. O parâmetro `--peer` pode ser repetido e aceita `id:host:porta` ou `host:porta`.

Em máquinas diferentes, substitua `127.0.0.1` pelo IP alcançável do outro computador. O servidor pode escutar em `0.0.0.0`, mas peers e clientes devem usar um endereço real, nunca `0.0.0.0`.

## Demonstração de failover

1. Execute os dois nós e o cliente conforme o exemplo.
2. Movimente o carro e confirme que o cliente exibe `lider=10`.
3. Encerre o processo do nó 10.
4. Após as sondagens do watchdog, o nó 5 aumenta o termo, vence a eleição e assume a partida.
5. O cliente percorre os servidores conhecidos, encontra o novo líder e continua enviando comandos.
6. Reinicie o nó 10 com o nó 5 como peer. Antes de concorrer, ele recupera o snapshot mais recente; por ter maior ID, volta a ser líder sem apagar o estado.

Exemplo de retorno do nó 10:

```bash
python distributed_racing.py server --host 0.0.0.0 --id 10 --port 7001 --peer 5:127.0.0.1:7002
```

## Testes automatizados

Os testes não abrem o Pygame. A suíte inclui regras do relógio de Lamport, rejeição de snapshots antigos, validação do líder declarado, eleição, failover e recuperação de nó.

```bash
python -m unittest discover -s tests -v
```

## Estudo reproduzível de falhas

```bash
python scripts/failure_study.py --trials 5 --json-output docs/resultados_falhas.json --markdown-output docs/RESULTADOS_FALHAS.md
```

O estudo inicia dois processos em `localhost`, confirma a replicação da entrada de um jogador, encerra abruptamente o líder e mede o tempo até a promoção da réplica. Os resultados atuais estão em [`docs/RESULTADOS_FALHAS.md`](docs/RESULTADOS_FALHAS.md).

## Estado e observabilidade

A operação `status` do protocolo requisição-resposta retorna, entre outros campos:

- `leader_id` e `leader_term`;
- versão e conteúdo do último snapshot;
- progresso de cada réplica (`last_acked_version`, falhas consecutivas e atraso do último ACK);
- papel do nó e indicação de execução degradada;
- contadores de eleição, replicação, rejeição e tempo do último failover.

Isso permite inspecionar o sistema sem depender da interface gráfica.

```bash
python distributed_racing.py status --server 127.0.0.1:7001
```

## Controles

| Tecla | Ação |
|---|---|
| `W` / `↑` | Direcionar para cima |
| `S` / `↓` | Direcionar para baixo |
| `A` / `←` | Direcionar para a esquerda |
| `D` / `→` | Direcionar para a direita |
| `X` / `Enter` | Acelerar |
| `Shift` | Drift |
| `R` | Boost |
| `G` | Mostrar vetores de velocidade |

## Limites conhecidos

- O modelo trata falhas crash-stop/crash-recovery e omissões temporárias; não trata nós maliciosos.
- Uma partição prolongada pode formar líderes isolados, pois ainda não há quorum ou consenso majoritário.
- Snapshots completos são simples e adequados ao protótipo, mas consomem mais banda que logs incrementais.
- A execução com somente dois nós favorece disponibilidade. Garantias fortes contra split-brain exigiriam pelo menos três nós e quorum.
