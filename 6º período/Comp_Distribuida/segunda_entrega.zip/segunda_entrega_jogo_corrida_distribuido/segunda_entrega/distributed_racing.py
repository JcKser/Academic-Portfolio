import argparse
import asyncio
import json
import math
import queue
import random
import socket
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple


DEFAULT_PORT = 7001


WIDTH, HEIGHT = 1000, 700
WORLD_WIDTH, WORLD_HEIGHT = 2200, 1600
SERVER_TICK_RATE = 60
SNAPSHOT_RATE = 15
LEADER_WATCHDOG_INTERVAL = 0.35
LEADER_FAILURE_THRESHOLD = 3
ELECTION_RPC_TIMEOUT = 0.45
ELECTION_COORDINATOR_TIMEOUT = 0.9
REPLICA_RPC_TIMEOUT = 0.25
REPLICA_RETRY_BASE = 0.10
REPLICA_RETRY_MAX = 1.50
TRACK_WIDTH = 220
CHECKPOINT_RADIUS = 95
TRACK_CENTERLINE = [
    (300, 840),
    (450, 500),
    (820, 280),
    (1240, 330),
    (1660, 510),
    (1900, 830),
    (1720, 1200),
    (1320, 1370),
    (860, 1280),
    (520, 1120),
]
CHECKPOINT_INDICES = [0, 2, 4, 6, 8]


# ---------------------------------------------------------------------------
# Math and game model
# ---------------------------------------------------------------------------


@dataclass
class Vec2:
    x: float = 0.0
    y: float = 0.0

    def copy(self) -> "Vec2":
        return Vec2(self.x, self.y)

    def __add__(self, other: "Vec2") -> "Vec2":
        return Vec2(self.x + other.x, self.y + other.y)

    def __sub__(self, other: "Vec2") -> "Vec2":
        return Vec2(self.x - other.x, self.y - other.y)

    def __mul__(self, value: float) -> "Vec2":
        return Vec2(self.x * value, self.y * value)

    __rmul__ = __mul__

    def __truediv__(self, value: float) -> "Vec2":
        return Vec2(self.x / value, self.y / value)

    def length_squared(self) -> float:
        return self.x * self.x + self.y * self.y

    def length(self) -> float:
        return math.sqrt(self.length_squared())

    def normalized(self) -> "Vec2":
        size = self.length()
        if size <= 0.00001:
            return Vec2()
        return self / size

    def dot(self, other: "Vec2") -> float:
        return self.x * other.x + self.y * other.y

    def rotate(self, degrees: float) -> "Vec2":
        radians = math.radians(degrees)
        cos_v = math.cos(radians)
        sin_v = math.sin(radians)
        return Vec2(self.x * cos_v - self.y * sin_v, self.x * sin_v + self.y * cos_v)

    def clamp_length(self, max_length: float) -> "Vec2":
        size = self.length()
        if size > max_length and size > 0:
            return self.normalized() * max_length
        return self

    def to_json(self) -> Dict[str, float]:
        return {"x": round(self.x, 3), "y": round(self.y, 3)}

    @staticmethod
    def from_json(data: Dict[str, Any]) -> "Vec2":
        return Vec2(float(data.get("x", 0.0)), float(data.get("y", 0.0)))


def sign(value: float) -> float:
    if value > 0.0:
        return 1.0
    if value < 0.0:
        return -1.0
    return 0.0


def default_input() -> Dict[str, bool]:
    return {
        "up": False,
        "down": False,
        "left": False,
        "right": False,
        "accelerate": False,
        "drift": False,
        "boost": False,
    }


class RaceTrack:
    def __init__(self, centerline: Iterable[Tuple[float, float]], width: float, checkpoints: Iterable[int]) -> None:
        self.points = [Vec2(x, y) for x, y in centerline]
        self.width = width
        self.checkpoint_indices = list(checkpoints)
        self.checkpoints = [self.points[index] for index in self.checkpoint_indices]

    def segment(self, index: int) -> Tuple[Vec2, Vec2]:
        return self.points[index], self.points[(index + 1) % len(self.points)]

    def spawn_for_slot(self, slot: int) -> Tuple[Vec2, float]:
        start = self.checkpoints[0]
        heading = self.heading_at_checkpoint(0)
        right = Vec2(math.cos(math.radians(heading + 90)), math.sin(math.radians(heading + 90)))
        row = slot // 3
        column = slot % 3 - 1
        spawn = start - Vec2(math.cos(math.radians(heading)), math.sin(math.radians(heading))) * (row * 58)
        spawn = spawn + right * (column * 54)
        return spawn, heading

    def heading_at_checkpoint(self, checkpoint_index: int) -> float:
        point_index = self.checkpoint_indices[checkpoint_index % len(self.checkpoint_indices)]
        start, end = self.segment(point_index)
        direction = (end - start).normalized()
        return math.degrees(math.atan2(direction.y, direction.x))

    def checkpoint_position(self, checkpoint_index: int) -> Vec2:
        return self.checkpoints[checkpoint_index % len(self.checkpoints)].copy()

    def next_checkpoint_index(self, checkpoint_index: int) -> int:
        return (checkpoint_index + 1) % len(self.checkpoints)

    def is_on_track(self, pos: Vec2) -> bool:
        distance, _, _ = self.closest_point(pos)
        return distance <= self.width / 2

    def closest_point(self, pos: Vec2) -> Tuple[float, int, Vec2]:
        best_distance = float("inf")
        best_segment = 0
        best_point = self.points[0]
        for index in range(len(self.points)):
            start, end = self.segment(index)
            segment = end - start
            segment_length_squared = segment.length_squared()
            t = 0.0
            if segment_length_squared > 0:
                t = max(0.0, min(1.0, (pos - start).dot(segment) / segment_length_squared))
            closest = start + segment * t
            distance = (pos - closest).length()
            if distance < best_distance:
                best_distance = distance
                best_segment = index
                best_point = closest
        return best_distance, best_segment, best_point


TRACK = RaceTrack(TRACK_CENTERLINE, TRACK_WIDTH, CHECKPOINT_INDICES)


@dataclass
class Car:
    player_id: str
    color: Tuple[int, int, int]
    pos: Vec2
    vel: Vec2 = field(default_factory=Vec2)
    angle: float = 0.0
    width: int = 42
    height: int = 22
    last_input: Dict[str, bool] = field(default_factory=default_input)
    last_seen: float = field(default_factory=time.monotonic)

    max_speed: float = 520.0
    friction: float = 0.985
    lateral_friction: float = 0.045
    drift_lateral_friction: float = 0.0
    drift_minimum_speed: float = 190.0
    drift_angle_offset: float = 25.0
    drift_bleedout: float = 1.8
    drift_max_wish_angle: float = 10.0
    normalized_angle: float = 32.0
    drift_normalized_angle: float = 6.0
    drift_amount: float = 0.0
    drift_direction: int = 0
    is_drifting: bool = False
    checkpoint_index: int = 0
    laps: int = 0
    deaths: int = 0

    def forward(self) -> Vec2:
        radians = math.radians(self.angle)
        return Vec2(math.cos(radians), math.sin(radians))

    def accelerate(self, vel: Vec2, wish_dir: Vec2, wish_speed: float, accel: float, dt: float) -> Vec2:
        current_speed = vel.dot(wish_dir)
        add_speed = wish_speed - current_speed
        linear_add_speed = wish_speed - vel.length()
        if add_speed <= 0:
            return vel.copy()

        add_speed = max(add_speed, linear_add_speed)
        accel_speed = min(accel * wish_speed * dt, add_speed)
        new_velocity = vel + wish_dir * accel_speed

        if new_velocity.length() > wish_speed:
            kept_size = max(vel.length(), min(new_velocity.length(), wish_speed))
            new_velocity = new_velocity.normalized() * kept_size
        return new_velocity

    def steer_velocity(self, vel: Vec2, wish_dir: Vec2, wish_speed: float, accel: float, dt: float) -> Vec2:
        current_speed_vec = vel.copy()
        if vel.length_squared() > 0 and vel.length() > wish_speed:
            current_speed_vec = vel.normalized()

        add_speed = wish_speed - current_speed_vec.dot(wish_dir)
        if add_speed <= 0:
            return vel.copy()

        accel_speed = min(accel * wish_speed * dt, add_speed)
        new_velocity = vel + wish_dir * accel_speed
        if new_velocity.length_squared() > 0:
            return new_velocity.normalized() * vel.length()
        return vel.copy()

    def update(self, dt: float) -> None:
        data = self.last_input
        self.last_seen = self.last_seen
        forward = self.forward()
        steer_forward = Vec2(0, 1)
        steer_input = Vec2()

        if data.get("up"):
            steer_input.y = 1
        elif data.get("down"):
            steer_input.y = -1
        if data.get("left"):
            steer_input.x = -1
        elif data.get("right"):
            steer_input.x = 1

        drift_pressed = bool(data.get("drift"))
        if drift_pressed and self.vel.length() > self.drift_minimum_speed:
            if not self.is_drifting and steer_input.x != 0:
                self.is_drifting = True
                self.drift_direction = 1 if steer_input.x > 0 else -1
        else:
            self.is_drifting = False
            self.drift_direction = 0

        vel_forward = self.vel.normalized() if self.vel.length_squared() > 0 else forward
        wish_dir = Vec2()
        drift_angle_steer_offset = 0.0

        if steer_input.length_squared() > 0:
            steer_input = steer_input.normalized()
            cos_v = steer_forward.dot(steer_input)
            max_turn_cos = -0.5
            modifier = 1 - (max(min(cos_v, 1.0), max_turn_cos) + 0.5) / 1.5
            turn_dir = 1 if steer_input.x > 0 else (-1 if steer_input.x < 0 else 0)
            max_wish_angle = self.drift_normalized_angle if self.is_drifting else self.normalized_angle
            wish_angle_offset = turn_dir * (modifier * max_wish_angle)
            drift_angle_steer_offset = turn_dir * (modifier * self.drift_max_wish_angle)
            wish_dir = vel_forward.rotate(wish_angle_offset).normalized()
            if self.vel.length_squared() > 0:
                wish_dir = wish_dir * max(0.0, self.vel.length() / self.max_speed)

        if data.get("boost"):
            self.vel = self.vel + forward * 800
            data["boost"] = False

        is_accelerating = data.get("accelerate")
        quake_accel_factor = 3.0

        if is_accelerating:
            self.vel = self.accelerate(self.vel, forward, self.max_speed, quake_accel_factor, dt)
            if wish_dir.length_squared() > 0:
                self.vel = self.steer_velocity(self.vel, wish_dir, self.max_speed, quake_accel_factor, dt)
        else:
            if wish_dir.length_squared() > 0 and self.vel.length_squared() > 0:
                self.vel = self.steer_velocity(self.vel, wish_dir, self.max_speed, quake_accel_factor, dt)
            self.vel = self.vel * self.friction

        if data.get("down") and self.vel.length() > 0:
            self.vel = self.vel * 0.985

        right_vector = forward.rotate(90)
        lateral_force = self.vel.dot(right_vector)
        lateral_friction = self.drift_lateral_friction if self.is_drifting else self.lateral_friction
        self.vel = self.vel - right_vector * lateral_force * lateral_friction

        if self.vel.length() < 5 and not is_accelerating:
            self.vel = Vec2()

        self.pos = self.pos + self.vel * dt

        if self.vel.length_squared() > 1.0:
            base_angle = math.degrees(math.atan2(self.vel.y, self.vel.x))
            if self.is_drifting:
                self.drift_amount = (self.drift_angle_offset * self.drift_direction) + drift_angle_steer_offset
            else:
                self.drift_amount = max(0.0, abs(self.drift_amount) - self.drift_bleedout) * sign(self.drift_amount)
            self.angle = (base_angle + self.drift_amount) % 360

    def to_json(self) -> Dict[str, Any]:
        return {
            "player_id": self.player_id,
            "color": list(self.color),
            "pos": self.pos.to_json(),
            "vel": self.vel.to_json(),
            "angle": round(self.angle, 3),
            "is_drifting": self.is_drifting,
            "checkpoint_index": self.checkpoint_index,
            "laps": self.laps,
            "deaths": self.deaths,
            "last_seen": round(self.last_seen, 3),
        }

    @staticmethod
    def from_json(data: Dict[str, Any]) -> "Car":
        color_data = data.get("color", [120, 220, 120])
        car = Car(
            player_id=str(data.get("player_id", "unknown")),
            color=(int(color_data[0]), int(color_data[1]), int(color_data[2])),
            pos=Vec2.from_json(data.get("pos", {})),
            vel=Vec2.from_json(data.get("vel", {})),
            angle=float(data.get("angle", 0.0)),
            last_seen=float(data.get("last_seen", time.monotonic())),
        )
        car.is_drifting = bool(data.get("is_drifting", False))
        car.checkpoint_index = int(data.get("checkpoint_index", 0))
        car.laps = int(data.get("laps", 0))
        car.deaths = int(data.get("deaths", 0))
        return car


class GameWorld:
    def __init__(self) -> None:
        self.players: Dict[str, Car] = {}
        self.version = 0
        self.leader_id: Optional[int] = None
        self.leader_term = 0
        self.logical_clock = 0

    def add_player(self, player_id: str, color: Tuple[int, int, int]) -> Car:
        if player_id in self.players:
            return self.players[player_id]
        spawn, angle = TRACK.spawn_for_slot(len(self.players))
        car = Car(player_id=player_id, color=color, pos=spawn, angle=angle)
        self.players[player_id] = car
        self.version += 1
        return car

    def set_input(self, player_id: str, input_state: Dict[str, bool], color: Tuple[int, int, int]) -> None:
        car = self.add_player(player_id, color)
        clean_input = default_input()
        for key in clean_input:
            clean_input[key] = bool(input_state.get(key))
        car.last_input = clean_input
        car.last_seen = time.monotonic()

    def remove_idle_players(self, now: float, timeout: float = 45.0) -> None:
        stale = [pid for pid, car in self.players.items() if now - car.last_seen > timeout]
        for pid in stale:
            del self.players[pid]
            self.version += 1

    def update(self, dt: float) -> None:
        for car in list(self.players.values()):
            car.update(dt)
            self.update_race_state(car)
        self.remove_idle_players(time.monotonic())
        self.version += 1

    def update_race_state(self, car: Car) -> None:
        if not TRACK.is_on_track(car.pos):
            self.respawn_car(car)
            return

        next_checkpoint = TRACK.next_checkpoint_index(car.checkpoint_index)
        checkpoint_pos = TRACK.checkpoint_position(next_checkpoint)
        if (car.pos - checkpoint_pos).length() <= CHECKPOINT_RADIUS:
            if next_checkpoint == 0:
                car.laps += 1
            car.checkpoint_index = next_checkpoint

    def respawn_car(self, car: Car) -> None:
        car.deaths += 1
        car.pos = TRACK.checkpoint_position(car.checkpoint_index)
        car.angle = TRACK.heading_at_checkpoint(car.checkpoint_index)
        car.vel = Vec2()
        car.drift_amount = 0.0
        car.drift_direction = 0
        car.is_drifting = False

    def snapshot(self, leader_id: Optional[int], logical_clock: int, leader_term: int = 0) -> Dict[str, Any]:
        self.leader_id = leader_id
        self.leader_term = int(leader_term)
        self.logical_clock = logical_clock
        return {
            "leader_id": leader_id,
            "leader_term": self.leader_term,
            "logical_clock": logical_clock,
            "version": self.version,
            "world": {
                "width": WORLD_WIDTH,
                "height": WORLD_HEIGHT,
                "track_width": TRACK_WIDTH,
                "checkpoint_radius": CHECKPOINT_RADIUS,
                "track": [point.to_json() for point in TRACK.points],
                "checkpoints": [point.to_json() for point in TRACK.checkpoints],
            },
            "players": [car.to_json() for car in self.players.values()],
        }

    def load_snapshot(self, snapshot: Dict[str, Any]) -> Tuple[bool, str]:
        incoming_clock = int(snapshot.get("logical_clock", 0))
        incoming_version = int(snapshot.get("version", 0))
        incoming_term = int(snapshot.get("leader_term", 0))
        if incoming_term < self.leader_term:
            return False, "stale_term"
        if incoming_term == self.leader_term and incoming_version < self.version:
            return False, "stale_version"
        self.leader_id = snapshot.get("leader_id")
        self.leader_term = incoming_term
        self.logical_clock = incoming_clock
        self.version = incoming_version
        self.players = {
            str(car_data.get("player_id")): Car.from_json(car_data)
            for car_data in snapshot.get("players", [])
        }
        return True, "applied"


# ---------------------------------------------------------------------------
# Distributed infrastructure: Lamport clock, JSON-RPC and Bully election
# ---------------------------------------------------------------------------


class LamportClock:
    def __init__(self) -> None:
        self.value = 0

    def tick(self) -> int:
        self.value += 1
        return self.value

    def observe(self, remote_value: Any) -> int:
        try:
            remote_int = int(remote_value)
        except (TypeError, ValueError):
            remote_int = 0
        self.value = max(self.value, remote_int) + 1
        return self.value


@dataclass(frozen=True)
class Peer:
    node_id: int
    host: str
    port: int

    @property
    def address(self) -> Tuple[str, int]:
        return (self.host, self.port)


@dataclass
class ReplicaProgress:
    """Estado observado pelo líder para cada réplica conhecida."""

    last_acked_term: int = 0
    last_acked_version: int = -1
    last_ack_at: float = 0.0
    consecutive_failures: int = 0
    retry_after: float = 0.0
    last_error: str = ""

    def as_dict(self, now: float) -> Dict[str, Any]:
        return {
            "last_acked_term": self.last_acked_term,
            "last_acked_version": self.last_acked_version,
            "ack_age_seconds": round(now - self.last_ack_at, 3) if self.last_ack_at else None,
            "consecutive_failures": self.consecutive_failures,
            "retry_in_seconds": round(max(0.0, self.retry_after - now), 3),
            "last_error": self.last_error or None,
        }


async def rpc_call(
    host: str,
    port: int,
    sender_id: str,
    clock_value: int,
    method: str,
    params: Optional[Dict[str, Any]] = None,
    timeout: float = 1.0,
) -> Dict[str, Any]:
    request_id = str(uuid.uuid4())
    message = {
        "type": "request",
        "id": request_id,
        "sender": sender_id,
        "clock": clock_value,
        "method": method,
        "params": params or {},
    }
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter
    reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port), timeout=timeout)
    try:
        writer.write((json.dumps(message) + "\n").encode("utf-8"))
        await asyncio.wait_for(writer.drain(), timeout=timeout)
        raw = await asyncio.wait_for(reader.readline(), timeout=timeout)
        if not raw:
            raise ConnectionError("empty RPC response")
        response = json.loads(raw.decode("utf-8"))
        if response.get("type") != "response" or response.get("id") != request_id:
            raise ConnectionError("invalid RPC response")
        if response.get("error"):
            raise RuntimeError(response["error"])
        return response
    finally:
        writer.close()
        await writer.wait_closed()


def sync_rpc_call(
    host: str,
    port: int,
    sender_id: str,
    method: str,
    params: Optional[Dict[str, Any]] = None,
    timeout: float = 0.35,
) -> Dict[str, Any]:
    request_id = str(uuid.uuid4())
    message = {
        "type": "request",
        "id": request_id,
        "sender": sender_id,
        "clock": int(time.monotonic() * 1000),
        "method": method,
        "params": params or {},
    }
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        sock.sendall((json.dumps(message) + "\n").encode("utf-8"))
        chunks = bytearray()
        while not chunks.endswith(b"\n"):
            chunk = sock.recv(4096)
            if not chunk:
                break
            chunks.extend(chunk)
        if not chunks:
            raise ConnectionError("empty RPC response")
        response = json.loads(chunks.decode("utf-8"))
        if response.get("type") != "response" or response.get("id") != request_id:
            raise ConnectionError("invalid RPC response")
        if response.get("error"):
            raise RuntimeError(response["error"])
        return response


class DistributedGameNode:
    """Nó primário-réplica com eleição Bully e controle explícito de versões."""

    def __init__(self, node_id: int, host: str, port: int, peers: Iterable[Peer]) -> None:
        self.node_id = node_id
        self.host = host
        self.port = port
        self.peers = {peer.node_id: peer for peer in peers if peer.node_id != node_id}
        self.clock = LamportClock()
        self.world = GameWorld()
        self.current_term = 0
        self.leader_id: Optional[int] = None
        self.last_leader_contact = 0.0
        self.leader_failures = 0
        self.election_running = False
        self.election_started_at: Optional[float] = None
        self.server: Optional[asyncio.AbstractServer] = None
        self.replica_progress: Dict[int, ReplicaProgress] = {
            peer_id: ReplicaProgress() for peer_id in self.peers
        }
        self.metrics: Dict[str, Any] = {
            "started_at": time.time(),
            "elections_started": 0,
            "leadership_changes": 0,
            "leader_failures_detected": 0,
            "snapshots_sent": 0,
            "snapshots_acked": 0,
            "snapshots_rejected": 0,
            "replication_failures": 0,
            "last_failover_seconds": None,
        }

    @property
    def sender_id(self) -> str:
        return f"node-{self.node_id}"

    def leader_peer(self) -> Optional[Peer]:
        if self.leader_id == self.node_id:
            return Peer(self.node_id, self.host, self.port)
        if self.leader_id is None:
            return None
        return self.peers.get(self.leader_id)

    async def start(self) -> None:
        # O socket é aberto antes da eleição para que mensagens coordinator possam
        # chegar durante a inicialização. Clientes recebem retry enquanto não há líder.
        self.server = await asyncio.start_server(self.handle_connection, self.host, self.port)
        print(f"[node {self.node_id}] listening on {self.host}:{self.port}")
        await self.start_election()
        asyncio.create_task(self.game_loop())
        asyncio.create_task(self.leader_watchdog())
        async with self.server:
            await self.server.serve_forever()

    async def handle_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer_address = writer.get_extra_info("peername")
        remote_host = peer_address[0] if peer_address else None
        try:
            raw = await reader.readline()
            if not raw:
                return
            message = json.loads(raw.decode("utf-8"))
            self.clock.observe(message.get("clock"))
            result = await self.dispatch(message.get("method", ""), message.get("params", {}), remote_host)
            response = {
                "type": "response",
                "id": message.get("id"),
                "sender": self.sender_id,
                "clock": self.clock.tick(),
                "result": result,
                "error": None,
            }
        except Exception as exc:
            response = {
                "type": "response",
                "id": None,
                "sender": self.sender_id,
                "clock": self.clock.tick(),
                "result": None,
                "error": str(exc),
            }
        writer.write((json.dumps(response) + "\n").encode("utf-8"))
        await writer.drain()
        writer.close()
        await writer.wait_closed()

    async def dispatch(self, method: str, params: Dict[str, Any], remote_host: Optional[str] = None) -> Dict[str, Any]:
        if method == "status":
            return self.status()
        if method == "join_player":
            return await self.join_player(params)
        if method == "submit_input":
            return await self.submit_input(params)
        if method == "replicate_snapshot":
            return self.replicate_snapshot(params)
        if method == "election":
            return await self.receive_election(params, remote_host)
        if method == "coordinator":
            return self.receive_coordinator(params, remote_host)
        raise ValueError(f"unknown method: {method}")

    def register_peer_from(self, node_id: int, params: Dict[str, Any], remote_host: Optional[str]) -> None:
        if not remote_host or int(node_id) == self.node_id:
            return
        port = params.get("port")
        if port is None:
            return
        new_peer = Peer(int(node_id), remote_host, int(port))
        existing = self.peers.get(int(node_id))
        self.peers[int(node_id)] = new_peer
        self.replica_progress.setdefault(int(node_id), ReplicaProgress())
        if existing != new_peer:
            print(f"[node {self.node_id}] registered peer {node_id} at {remote_host}:{port}")

    def status(self) -> Dict[str, Any]:
        snapshot = self.world.snapshot(
            self.leader_id, self.clock.tick(), self.current_term
        )
        now = time.monotonic()
        healthy_replicas = sum(
            1
            for progress in self.replica_progress.values()
            if progress.last_acked_term == self.current_term
            and progress.last_ack_at
            and now - progress.last_ack_at <= 2.0
        )
        return {
            "node_id": self.node_id,
            "leader_id": self.leader_id,
            "leader_term": self.current_term,
            "logical_clock": self.clock.value,
            "players": len(self.world.players),
            "snapshot": snapshot,
            "servers": self.describe_cluster(),
            "replicas": self.describe_replicas(),
            "availability": {
                "role": "leader" if self.leader_id == self.node_id else "follower",
                "healthy_replicas": healthy_replicas,
                "degraded": self.leader_id == self.node_id and bool(self.peers) and healthy_replicas == 0,
            },
            "metrics": dict(self.metrics),
        }

    def follower_response(self) -> Dict[str, Any]:
        return {
            "redirect": self.describe_leader(),
            "retry": self.leader_id is None,
            "snapshot": self.world.snapshot(
                self.leader_id, self.clock.tick(), self.current_term
            ),
            "servers": self.describe_cluster(),
        }

    async def join_player(self, params: Dict[str, Any]) -> Dict[str, Any]:
        if self.leader_id != self.node_id:
            return self.follower_response()
        player_id = str(params.get("player_id", "player"))
        color = parse_color(params.get("color"))
        self.world.add_player(player_id, color)
        snapshot = self.world.snapshot(
            self.leader_id, self.clock.tick(), self.current_term
        )
        # Entrada de jogador é um evento estrutural: tenta obter ACK antes de responder.
        acks = await self.broadcast_snapshot(snapshot, wait_for_acks=True, force=True)
        return {
            "redirect": None,
            "retry": False,
            "snapshot": snapshot,
            "servers": self.describe_cluster(),
            "replication": {
                "acked_replicas": acks,
                "known_replicas": len(self.peers),
                "degraded": bool(self.peers) and acks == 0,
            },
        }

    async def submit_input(self, params: Dict[str, Any]) -> Dict[str, Any]:
        if self.leader_id != self.node_id:
            return self.follower_response()
        return await self.apply_player_input(params)

    async def apply_player_input(self, params: Dict[str, Any]) -> Dict[str, Any]:
        player_id = str(params.get("player_id", "player"))
        color = parse_color(params.get("color"))
        input_state = params.get("input", {})
        self.world.set_input(player_id, input_state, color)
        return {
            "redirect": None,
            "retry": False,
            "snapshot": self.world.snapshot(
                self.leader_id, self.clock.tick(), self.current_term
            ),
            "servers": self.describe_cluster(),
        }

    def replicate_snapshot(self, params: Dict[str, Any]) -> Dict[str, Any]:
        snapshot = params.get("snapshot", {})
        incoming_leader = int(snapshot.get("leader_id", -1))
        incoming_term = int(snapshot.get("leader_term", 0))

        if incoming_leader < 0:
            self.metrics["snapshots_rejected"] += 1
            return self.replication_rejection("invalid_leader")
        if incoming_term < self.current_term:
            self.metrics["snapshots_rejected"] += 1
            return self.replication_rejection("stale_term")
        if (
            incoming_term == self.current_term
            and self.leader_id not in (None, incoming_leader)
            and incoming_leader < int(self.leader_id)
        ):
            self.metrics["snapshots_rejected"] += 1
            return self.replication_rejection("conflicting_lower_priority_leader")

        accepted, reason = self.world.load_snapshot(snapshot)
        if not accepted:
            self.metrics["snapshots_rejected"] += 1
            return self.replication_rejection(reason)

        self.current_term = incoming_term
        self.leader_id = incoming_leader
        self.world.leader_id = incoming_leader
        self.last_leader_contact = time.monotonic()
        self.leader_failures = 0
        self.clock.observe(snapshot.get("logical_clock"))
        return {
            "accepted": True,
            "reason": "applied",
            "leader_id": self.leader_id,
            "leader_term": self.current_term,
            "applied_version": self.world.version,
            "logical_clock": self.clock.value,
        }

    def replication_rejection(self, reason: str) -> Dict[str, Any]:
        return {
            "accepted": False,
            "reason": reason,
            "leader_id": self.leader_id,
            "leader_term": self.current_term,
            "applied_version": self.world.version,
        }

    async def receive_election(self, params: Dict[str, Any], remote_host: Optional[str] = None) -> Dict[str, Any]:
        candidate_id = int(params.get("candidate_id", -1))
        incoming_term = int(params.get("term", 0))
        self.register_peer_from(candidate_id, params, remote_host)
        if incoming_term > self.current_term:
            self.current_term = incoming_term
            if self.leader_id != self.node_id:
                self.leader_id = None
        if self.node_id > candidate_id:
            print(f"[node {self.node_id}] election request from lower node {candidate_id} term={incoming_term}")
            if self.leader_id == self.node_id:
                asyncio.create_task(self._send_coordinator_to(candidate_id))
            elif not self.election_running:
                asyncio.create_task(self.delayed_election(0.05))
            return {
                "ok": True,
                "higher": True,
                "node_id": self.node_id,
                "term": self.current_term,
            }
        return {
            "ok": True,
            "higher": False,
            "node_id": self.node_id,
            "term": self.current_term,
        }

    async def _send_coordinator_to(self, peer_id: int) -> None:
        peer = self.peers.get(peer_id)
        if not peer:
            return
        try:
            await rpc_call(
                peer.host,
                peer.port,
                self.sender_id,
                self.clock.tick(),
                "coordinator",
                {"leader_id": self.node_id, "port": self.port, "term": self.current_term},
                timeout=ELECTION_RPC_TIMEOUT,
            )
        except Exception:
            return

    def receive_coordinator(self, params: Dict[str, Any], remote_host: Optional[str] = None) -> Dict[str, Any]:
        new_leader = int(params.get("leader_id"))
        new_term = int(params.get("term", 0))
        self.register_peer_from(new_leader, params, remote_host)
        if new_term < self.current_term:
            return {"accepted": False, "reason": "stale_term", "term": self.current_term}
        if (
            new_term == self.current_term
            and self.leader_id not in (None, new_leader)
            and new_leader < int(self.leader_id)
        ):
            return {"accepted": False, "reason": "lower_priority_leader", "term": self.current_term}
        self.current_term = new_term
        self.leader_id = new_leader
        self.world.leader_id = new_leader
        self.world.leader_term = new_term
        self.last_leader_contact = time.monotonic()
        self.leader_failures = 0
        print(f"[node {self.node_id}] coordinator is node {new_leader} term={new_term}")
        return {"accepted": True, "leader_id": self.leader_id, "term": self.current_term}

    async def delayed_election(self, delay: float) -> None:
        await asyncio.sleep(delay)
        await self.start_election()

    async def synchronize_from_peers(self) -> None:
        """Obtém o maior termo e o snapshot mais novo antes de concorrer à liderança."""
        tasks = [
            rpc_call(
                peer.host,
                peer.port,
                self.sender_id,
                self.clock.tick(),
                "status",
                {},
                timeout=ELECTION_RPC_TIMEOUT,
            )
            for peer in self.peers.values()
        ]
        if not tasks:
            return
        results = await asyncio.gather(*tasks, return_exceptions=True)
        candidates: List[Dict[str, Any]] = []
        for response in results:
            if not isinstance(response, dict):
                continue
            self.clock.observe(response.get("clock"))
            result = response.get("result", {})
            self.current_term = max(self.current_term, int(result.get("leader_term", 0)))
            snapshot = result.get("snapshot")
            if isinstance(snapshot, dict):
                candidates.append(snapshot)
        if candidates:
            newest = max(
                candidates,
                key=lambda snap: (
                    int(snap.get("leader_term", 0)),
                    int(snap.get("version", 0)),
                ),
            )
            self.world.load_snapshot(newest)

    async def start_election(self) -> None:
        if self.election_running:
            return
        self.election_running = True
        self.election_started_at = time.monotonic()
        self.metrics["elections_started"] += 1
        try:
            await self.synchronize_from_peers()
            self.current_term += 1
            election_term = self.current_term
            self.leader_id = None
            print(f"[node {self.node_id}] starting Bully election term={election_term}")
            higher_peers = [peer for peer in self.peers.values() if peer.node_id > self.node_id]
            higher_alive = False
            for peer in higher_peers:
                try:
                    response = await rpc_call(
                        peer.host,
                        peer.port,
                        self.sender_id,
                        self.clock.tick(),
                        "election",
                        {"candidate_id": self.node_id, "port": self.port, "term": election_term},
                        timeout=ELECTION_RPC_TIMEOUT,
                    )
                    self.clock.observe(response.get("clock"))
                    result = response.get("result", {})
                    self.current_term = max(self.current_term, int(result.get("term", election_term)))
                    higher_alive = higher_alive or bool(result.get("higher"))
                except Exception:
                    continue

            if not higher_alive:
                await self.become_leader(self.current_term)
            else:
                deadline = time.monotonic() + ELECTION_COORDINATOR_TIMEOUT
                while self.leader_id is None and time.monotonic() < deadline:
                    await asyncio.sleep(0.05)
                if self.leader_id is None:
                    asyncio.create_task(self.delayed_election(0.10))
        finally:
            self.election_running = False

    async def become_leader(self, term: Optional[int] = None) -> None:
        previous_leader = self.leader_id
        self.current_term = max(self.current_term, int(term or 0))
        if previous_leader != self.node_id:
            print(f"[node {self.node_id}] became leader term={self.current_term}")
            self.metrics["leadership_changes"] += 1
        self.leader_id = self.node_id
        self.world.leader_id = self.node_id
        self.world.leader_term = self.current_term
        self.last_leader_contact = time.monotonic()
        self.leader_failures = 0
        if self.election_started_at is not None:
            self.metrics["last_failover_seconds"] = round(
                time.monotonic() - self.election_started_at, 4
            )
        await self.broadcast(
            "coordinator",
            {"leader_id": self.node_id, "port": self.port, "term": self.current_term},
        )
        snapshot = self.world.snapshot(self.leader_id, self.clock.tick(), self.current_term)
        await self.broadcast_snapshot(snapshot, wait_for_acks=False, force=True)

    async def can_reach_leader(self) -> bool:
        leader = self.leader_peer()
        if not leader:
            return False
        try:
            response = await rpc_call(
                leader.host,
                leader.port,
                self.sender_id,
                self.clock.tick(),
                "status",
                {},
                timeout=ELECTION_RPC_TIMEOUT,
            )
            self.clock.observe(response.get("clock"))
            result = response.get("result", {})
            remote_term = int(result.get("leader_term", 0))
            remote_leader = result.get("leader_id")
            if remote_term < self.current_term or remote_leader is None:
                return False
            self.current_term = remote_term
            self.leader_id = int(remote_leader)
            self.world.leader_term = remote_term
            self.last_leader_contact = time.monotonic()
            self.leader_failures = 0
            return True
        except Exception:
            return False

    async def leader_watchdog(self) -> None:
        while True:
            await asyncio.sleep(LEADER_WATCHDOG_INTERVAL)
            if self.leader_id is None:
                await self.start_election()
            elif self.leader_id != self.node_id:
                if await self.can_reach_leader():
                    continue
                self.leader_failures += 1
                if self.leader_failures < LEADER_FAILURE_THRESHOLD:
                    continue
                print(
                    f"[node {self.node_id}] leader unavailable after "
                    f"{self.leader_failures} probes; triggering election"
                )
                self.metrics["leader_failures_detected"] += 1
                self.leader_id = None
                await self.start_election()

    async def game_loop(self) -> None:
        last = time.monotonic()
        snapshot_accumulator = 0.0
        while True:
            now = time.monotonic()
            dt = min(now - last, 0.05)
            last = now
            if self.leader_id == self.node_id:
                self.world.update(dt)
                snapshot_accumulator += dt
                if snapshot_accumulator >= 1.0 / SNAPSHOT_RATE:
                    snapshot_accumulator = 0.0
                    snapshot = self.world.snapshot(
                        self.leader_id, self.clock.tick(), self.current_term
                    )
                    await self.broadcast_snapshot(snapshot)
            await asyncio.sleep(1.0 / SERVER_TICK_RATE)

    async def broadcast_snapshot(
        self,
        snapshot: Dict[str, Any],
        wait_for_acks: bool = False,
        force: bool = False,
    ) -> int:
        tasks = [
            asyncio.create_task(
                self._safe_rpc(
                    peer,
                    "replicate_snapshot",
                    {"snapshot": snapshot},
                    REPLICA_RPC_TIMEOUT,
                    force=force,
                )
            )
            for peer in list(self.peers.values())
        ]
        if not tasks:
            return 0
        if not wait_for_acks:
            return 0
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return sum(result is True for result in results)

    async def _safe_rpc(
        self,
        peer: Peer,
        method: str,
        params: Dict[str, Any],
        timeout: float = REPLICA_RPC_TIMEOUT,
        force: bool = False,
    ) -> bool:
        progress = self.replica_progress.setdefault(peer.node_id, ReplicaProgress())
        now = time.monotonic()
        if not force and progress.retry_after > now:
            return False
        self.metrics["snapshots_sent"] += 1
        try:
            response = await rpc_call(
                peer.host,
                peer.port,
                self.sender_id,
                self.clock.tick(),
                method,
                params,
                timeout=timeout,
            )
            self.clock.observe(response.get("clock"))
            result = response.get("result", {})
            remote_term = int(result.get("leader_term", self.current_term))
            if remote_term > self.current_term:
                self.current_term = remote_term
                remote_leader = result.get("leader_id")
                self.leader_id = int(remote_leader) if remote_leader is not None else None
                return False
            if result.get("accepted") is not True:
                self.metrics["snapshots_rejected"] += 1
                progress.last_error = str(result.get("reason", "rejected"))
                return False
            progress.last_acked_term = remote_term
            progress.last_acked_version = int(result.get("applied_version", -1))
            progress.last_ack_at = time.monotonic()
            progress.consecutive_failures = 0
            progress.retry_after = 0.0
            progress.last_error = ""
            self.metrics["snapshots_acked"] += 1
            return True
        except Exception as exc:
            progress.consecutive_failures += 1
            delay = min(
                REPLICA_RETRY_MAX,
                REPLICA_RETRY_BASE * (2 ** (progress.consecutive_failures - 1)),
            )
            progress.retry_after = time.monotonic() + delay
            progress.last_error = f"{type(exc).__name__}: {exc}"
            self.metrics["replication_failures"] += 1
            return False

    async def broadcast(self, method: str, params: Dict[str, Any], timeout: float = 0.5) -> None:
        tasks = [
            rpc_call(
                peer.host,
                peer.port,
                self.sender_id,
                self.clock.tick(),
                method,
                params,
                timeout=timeout,
            )
            for peer in self.peers.values()
        ]
        if not tasks:
            return
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for result in results:
            if isinstance(result, dict):
                self.clock.observe(result.get("clock"))

    def describe_leader(self) -> Optional[Dict[str, Any]]:
        leader = self.leader_peer()
        if not leader:
            return None
        return {
            "node_id": leader.node_id,
            "host": leader.host,
            "port": leader.port,
            "term": self.current_term,
        }

    def describe_cluster(self) -> List[Dict[str, Any]]:
        servers = [{"node_id": self.node_id, "host": self.host, "port": self.port}]
        servers.extend(
            {"node_id": peer.node_id, "host": peer.host, "port": peer.port}
            for peer in self.peers.values()
        )
        return sorted(servers, key=lambda server: int(server["node_id"]))

    def describe_replicas(self) -> List[Dict[str, Any]]:
        now = time.monotonic()
        return [
            {
                "node_id": peer_id,
                **self.replica_progress.setdefault(peer_id, ReplicaProgress()).as_dict(now),
            }
            for peer_id in sorted(self.peers)
        ]


def parse_color(value: Any) -> Tuple[int, int, int]:
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        return (int(value[0]), int(value[1]), int(value[2]))
    return (120, 220, 120)


# ---------------------------------------------------------------------------
# Pygame client and local mode
# ---------------------------------------------------------------------------


class NetworkClient:
    """Roda toda a comunicacao RPC em uma thread separada para que o
    pygame loop nunca bloqueie quando o lider esta caindo."""

    DEAD_COOLDOWN = 3.0
    SEND_RATE = 30.0

    def __init__(self, client_id: str, player_id: str, color: Tuple[int, int, int],
                 host: str, port: int) -> None:
        self.client_id = client_id
        self.player_id = player_id
        self.color = color
        self.target_host = host
        self.target_port = port
        self.known_servers: List[Dict[str, Any]] = []
        self.dead_until: Dict[Tuple[str, int], float] = {}
        self.snapshot: Dict[str, Any] = {"players": [], "world": {"width": WORLD_WIDTH, "height": WORLD_HEIGHT}}
        self.status_line = "conectando..."
        self.input_state: Dict[str, bool] = default_input()
        self.pending_boost = False
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self.remember_server(host, port)

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def submit_input(self, input_state: Dict[str, bool], pending_boost: bool) -> None:
        with self._lock:
            self.input_state = dict(input_state)
            if pending_boost:
                self.pending_boost = True

    def view(self) -> Tuple[Dict[str, Any], str]:
        with self._lock:
            return self.snapshot, self.status_line

    def remember_server(self, host: str, port: int, node_id: Optional[int] = None) -> None:
        for server in self.known_servers:
            if server["host"] == host and int(server["port"]) == int(port):
                if node_id is not None:
                    server["node_id"] = node_id
                return
        self.known_servers.append({"node_id": node_id, "host": host, "port": int(port)})

    LOCAL_HOSTS = {"0.0.0.0", "::", "127.0.0.1", "::1", "localhost"}

    def _resolve_host(self, host: str, source_host: str) -> str:
        # servidores anunciam loopback/wildcard internamente; do ponto de vista
        # do cliente remoto isso e' inalcancavel — substitui pelo IP que ja
        # funcionou para falar com o cluster (ex: o IP da Radmin VPN).
        if host in self.LOCAL_HOSTS:
            return source_host
        return host

    def remember_servers(self, result: Dict[str, Any], source_host: str, source_port: int) -> None:
        self.remember_server(source_host, source_port)
        for server in result.get("servers", []):
            host = self._resolve_host(str(server.get("host", source_host)), source_host)
            port = int(server.get("port", source_port))
            self.remember_server(host, port, server.get("node_id"))

    def server_candidates(self) -> List[Tuple[str, int]]:
        now = time.monotonic()
        candidates = [(self.target_host, self.target_port)]
        for server in self.known_servers:
            candidate = (str(server["host"]), int(server["port"]))
            if candidate not in candidates:
                candidates.append(candidate)
        live = [c for c in candidates if self.dead_until.get(c, 0) <= now]
        if live:
            return live
        # se todos estao mortos, expira os cooldowns para tentar novamente
        self.dead_until.clear()
        return candidates

    def _send(self, method: str, params: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        last_error = ""
        candidates = self.server_candidates()
        index = 0
        # timeout curto para nao acumular atraso quando varios estao mortos
        timeout = 0.18
        while index < len(candidates) and index < 6:
            host, port = candidates[index]
            index += 1
            now = time.monotonic()
            if self.dead_until.get((host, port), 0) > now:
                continue
            try:
                response = sync_rpc_call(host, port, self.client_id, method, params, timeout=timeout)
                self.dead_until.pop((host, port), None)
                result = response.get("result", {})
                self.remember_servers(result, host, port)
                if result.get("retry"):
                    last_error = f"{host}:{port} (cluster em eleicao)"
                    continue
                redirect = result.get("redirect")
                if redirect:
                    redirect_host = self._resolve_host(str(redirect["host"]), host)
                    redirect_port = int(redirect["port"])
                    redirect_candidate = (redirect_host, redirect_port)
                    self.remember_server(redirect_host, redirect_port, redirect.get("node_id"))
                    # se o redirect aponta para um servidor recem morto, ignora
                    if self.dead_until.get(redirect_candidate, 0) > now:
                        continue
                    with self._lock:
                        self.status_line = (
                            f"redirecionado para lider {redirect.get('node_id')} "
                            f"({redirect_host}:{redirect_port})"
                        )
                    if redirect_candidate not in candidates:
                        candidates.insert(index, redirect_candidate)
                    continue
                # so atualiza target em resposta valida com snapshot
                self.target_host, self.target_port = host, port
                return result
            except Exception as exc:
                self.dead_until[(host, port)] = time.monotonic() + self.DEAD_COOLDOWN
                last_error = f"{host}:{port} ({exc})"
        with self._lock:
            self.status_line = f"aguardando novo lider; sem resposta de {last_error}"
        return None

    def _run(self) -> None:
        # retentar join ate conseguir (servidor pode ainda estar elegendo lider)
        while not self._stop.is_set():
            join_result = self._send("join_player", {"player_id": self.player_id, "color": list(self.color)})
            if join_result is not None:
                if join_result.get("snapshot"):
                    with self._lock:
                        self.snapshot = join_result["snapshot"]
                break
            time.sleep(0.2)

        interval = 1.0 / self.SEND_RATE
        next_tick = time.monotonic()
        while not self._stop.is_set():
            with self._lock:
                input_state = dict(self.input_state)
                if self.pending_boost:
                    input_state["boost"] = True
                    self.pending_boost = False

            result = self._send(
                "submit_input",
                {
                    "player_id": self.player_id,
                    "color": list(self.color),
                    "input": input_state,
                    "client_time": time.time(),
                },
            )
            if result and result.get("snapshot"):
                snap = result["snapshot"]
                leader_id = snap.get("leader_id")
                clock_value = snap.get("logical_clock")
                players_count = len(snap.get("players", []))
                with self._lock:
                    self.snapshot = snap
                    self.status_line = (
                        f"lider={leader_id} servidor={self.target_host}:{self.target_port} "
                        f"relogio_logico={clock_value} jogadores={players_count}"
                    )

            next_tick += interval
            sleep_for = next_tick - time.monotonic()
            if sleep_for < 0:
                next_tick = time.monotonic()
            else:
                self._stop.wait(timeout=sleep_for)


def run_client(player_id: str, server_host: str, server_port: int) -> None:
    import pygame

    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption(f"Jogo Online Distribuido - {player_id}")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Consolas", 16)
    small_font = pygame.font.SysFont("Consolas", 13)

    client_id = f"client-{player_id}"
    color = choose_color(player_id)
    debug_enabled = False
    pending_boost = False

    network = NetworkClient(client_id, player_id, color, server_host, server_port)
    network.start()

    running = True
    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_g:
                    debug_enabled = not debug_enabled
                elif event.key == pygame.K_r:
                    pending_boost = True

        keys = pygame.key.get_pressed()
        input_state = {
            "up": keys[pygame.K_w] or keys[pygame.K_UP],
            "down": keys[pygame.K_s] or keys[pygame.K_DOWN],
            "left": keys[pygame.K_a] or keys[pygame.K_LEFT],
            "right": keys[pygame.K_d] or keys[pygame.K_RIGHT],
            "accelerate": keys[pygame.K_x] or keys[pygame.K_RETURN],
            "drift": keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT],
            "boost": False,
        }
        network.submit_input(input_state, pending_boost)
        pending_boost = False

        snapshot, status_line = network.view()
        draw_client_frame(screen, font, small_font, snapshot, player_id, status_line, debug_enabled)
        pygame.display.flip()

    network.stop()
    pygame.quit()


def draw_client_frame(
    screen: Any,
    font: Any,
    small_font: Any,
    snapshot: Dict[str, Any],
    player_id: str,
    status: str,
    debug_enabled: bool = False,
) -> None:
    import pygame

    screen.fill((29, 95, 63))
    players = snapshot.get("players", [])
    own = next((player for player in players if player.get("player_id") == player_id), None)
    own_pos = Vec2.from_json(own.get("pos", {})) if own else Vec2(WORLD_WIDTH / 2, WORLD_HEIGHT / 2)
    camera = Vec2(own_pos.x - WIDTH / 2, own_pos.y - HEIGHT / 2)
    camera.x = max(0, min(camera.x, max(0, WORLD_WIDTH - WIDTH)))
    camera.y = max(0, min(camera.y, max(0, WORLD_HEIGHT - HEIGHT)))

    draw_grid(screen, camera)
    draw_track(screen, camera)
    for player in players:
        draw_car(screen, player, camera, highlight=player.get("player_id") == player_id, debug_enabled=debug_enabled)

    pygame.draw.rect(screen, (28, 32, 38), (0, 0, WIDTH, 76))
    own_laps = own.get("laps", 0) if own else 0
    own_deaths = own.get("deaths", 0) if own else 0
    own_checkpoint = own.get("checkpoint_index", 0) if own else 0
    lines = [
        "W/A/S/D ou setas: direcao | X/Enter: acelerar | Shift: drift | R: boost | G: debug",
        status,
        f"voce: {player_id} | voltas={own_laps} checkpoint={own_checkpoint + 1}/{len(TRACK.checkpoints)} mortes={own_deaths}",
    ]
    for index, text in enumerate(lines):
        screen.blit(font.render(text, True, (238, 238, 238)), (12, 10 + index * 21))

    x = WIDTH - 230
    y = 12
    screen.blit(small_font.render("replicas do estado", True, (220, 220, 220)), (x, y))
    screen.blit(small_font.render(f"versao: {snapshot.get('version', 0)}", True, (180, 205, 255)), (x, y + 18))
    screen.blit(small_font.render(f"clock: {snapshot.get('logical_clock', 0)}", True, (180, 255, 210)), (x, y + 36))


def draw_grid(screen: Any, camera: Vec2) -> None:
    import pygame

    grid_color = (37, 110, 72)
    axis_color = (48, 129, 86)
    spacing = 100
    start_x = int(camera.x // spacing * spacing)
    start_y = int(camera.y // spacing * spacing)
    for x in range(start_x, int(camera.x + WIDTH) + spacing, spacing):
        color = axis_color if x == 0 else grid_color
        pygame.draw.line(screen, color, (x - camera.x, 0), (x - camera.x, HEIGHT))
    for y in range(start_y, int(camera.y + HEIGHT) + spacing, spacing):
        color = axis_color if y == 0 else grid_color
        pygame.draw.line(screen, color, (0, y - camera.y), (WIDTH, y - camera.y))

    pygame.draw.rect(
        screen,
        (82, 92, 105),
        (-camera.x, -camera.y, WORLD_WIDTH, WORLD_HEIGHT),
        width=2,
    )


def draw_track(screen: Any, camera: Vec2) -> None:
    import pygame

    def to_screen(point: Vec2) -> Tuple[int, int]:
        return int(point.x - camera.x), int(point.y - camera.y)

    points = [to_screen(point) for point in TRACK.points]
    if len(points) < 2:
        return

    closed_points = points + [points[0]]
    border_width = TRACK_WIDTH + 30
    pygame.draw.lines(screen, (162, 57, 57), False, closed_points, border_width)
    for point in points:
        pygame.draw.circle(screen, (162, 57, 57), point, border_width // 2)

    pygame.draw.lines(screen, (54, 58, 63), False, closed_points, TRACK_WIDTH)
    for point in points:
        pygame.draw.circle(screen, (54, 58, 63), point, TRACK_WIDTH // 2)

    pygame.draw.lines(screen, (82, 88, 94), False, closed_points, 4)

    dash_length = 26
    gap = 24
    for index in range(len(TRACK.points)):
        start, end = TRACK.segment(index)
        segment = end - start
        segment_length = segment.length()
        if segment_length <= 0:
            continue
        direction = segment.normalized()
        distance = 0.0
        while distance < segment_length:
            dash_start = start + direction * distance
            dash_end = start + direction * min(distance + dash_length, segment_length)
            pygame.draw.line(screen, (220, 220, 205), to_screen(dash_start), to_screen(dash_end), 3)
            distance += dash_length + gap

    for checkpoint_number, checkpoint in enumerate(TRACK.checkpoints, start=1):
        screen_pos = to_screen(checkpoint)
        pygame.draw.circle(screen, (80, 175, 235), screen_pos, CHECKPOINT_RADIUS, width=3)
        label_font = pygame.font.SysFont("Consolas", 18, bold=True)
        label = label_font.render(str(checkpoint_number), True, (230, 245, 255))
        screen.blit(label, (screen_pos[0] - label.get_width() // 2, screen_pos[1] - label.get_height() // 2))


def draw_car(screen: Any, car_data: Dict[str, Any], camera: Vec2, highlight: bool, debug_enabled: bool) -> None:
    import pygame

    pos = Vec2.from_json(car_data.get("pos", {}))
    vel = Vec2.from_json(car_data.get("vel", {}))
    angle = float(car_data.get("angle", 0.0))
    color = parse_color(car_data.get("color"))
    width, height = 42, 22

    car_surface = pygame.Surface((width, height), pygame.SRCALPHA)
    pygame.draw.rect(car_surface, color, (0, 0, width, height), border_radius=3)
    pygame.draw.rect(car_surface, (245, 245, 245), (width - 9, 5, 5, height - 10), border_radius=2)
    if car_data.get("is_drifting"):
        pygame.draw.rect(car_surface, (255, 230, 120), (4, 4, 7, height - 8), border_radius=2)

    rotated = pygame.transform.rotate(car_surface, -angle)
    rect = rotated.get_rect(center=(int(pos.x - camera.x), int(pos.y - camera.y)))
    screen.blit(rotated, rect.topleft)

    if highlight:
        pygame.draw.circle(screen, (255, 255, 255), rect.center, 30, width=2)

    if debug_enabled:
        forward = Vec2(math.cos(math.radians(angle)), math.sin(math.radians(angle)))
        center = Vec2(float(rect.centerx), float(rect.centery))
        vel_end = center + vel * 0.18
        forward_end = center + forward * 56
        pygame.draw.line(screen, (70, 170, 255), rect.center, (int(vel_end.x), int(vel_end.y)), 3)
        pygame.draw.line(screen, (255, 125, 70), rect.center, (int(forward_end.x), int(forward_end.y)), 2)

    label_font = pygame.font.SysFont("Consolas", 12)
    label = label_font.render(str(car_data.get("player_id", "")), True, (240, 240, 240))
    screen.blit(label, (rect.centerx - label.get_width() // 2, rect.top - 18))


def choose_color(seed_text: str) -> Tuple[int, int, int]:
    random.seed(seed_text)
    return (
        random.randint(80, 240),
        random.randint(90, 240),
        random.randint(100, 255),
    )


def run_local(player_id: str) -> None:
    import pygame

    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Modo local - fisica do carro")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Consolas", 16)
    world = GameWorld()
    color = choose_color(player_id)
    world.add_player(player_id, color)

    running = True
    debug_enabled = False
    pending_boost = False
    while running:
        dt = clock.tick(60) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_g:
                    debug_enabled = not debug_enabled
                elif event.key == pygame.K_r:
                    pending_boost = True

        keys = pygame.key.get_pressed()
        world.set_input(
            player_id,
            {
                "up": keys[pygame.K_w] or keys[pygame.K_UP],
                "down": keys[pygame.K_s] or keys[pygame.K_DOWN],
                "left": keys[pygame.K_a] or keys[pygame.K_LEFT],
                "right": keys[pygame.K_d] or keys[pygame.K_RIGHT],
                "accelerate": keys[pygame.K_x] or keys[pygame.K_RETURN],
                "drift": keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT],
                "boost": pending_boost,
            },
            color,
        )
        pending_boost = False
        world.update(dt)
        snapshot = world.snapshot(0, int(time.monotonic() * 1000))
        draw_client_frame(
            screen,
            font,
            pygame.font.SysFont("Consolas", 13),
            snapshot,
            player_id,
            "modo local",
            debug_enabled,
        )
        pygame.display.flip()

    pygame.quit()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def parse_peer(raw_peer: str) -> Peer:
    parts = raw_peer.split(":")
    try:
        if len(parts) == 3:
            raw_id, host, raw_port = parts
            return Peer(int(raw_id), host, int(raw_port))
        if len(parts) == 2:
            host, raw_port = parts
            return Peer(0, host, int(raw_port))
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "peer deve seguir o formato host:porta ou id:host:porta"
        ) from exc
    raise argparse.ArgumentTypeError("peer deve seguir o formato host:porta ou id:host:porta")


def parse_host_port(raw_value: str) -> Tuple[str, int]:
    if ":" not in raw_value:
        return raw_value, DEFAULT_PORT
    try:
        host, raw_port = raw_value.rsplit(":", 1)
        return host, int(raw_port)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("servidor deve seguir o formato host:porta") from exc


def discover_peer_id(host: str, port: int, timeout: float = 1.0) -> Optional[int]:
    try:
        response = sync_rpc_call(host, port, "discovery", "status", {}, timeout=timeout)
        result = response.get("result", {})
        node_id = result.get("node_id")
        return int(node_id) if node_id is not None else None
    except Exception:
        return None


def discover_cluster(seed: Peer, timeout: float = 1.0) -> List[Peer]:
    try:
        response = sync_rpc_call(seed.host, seed.port, "discovery", "status", {}, timeout=timeout)
        result = response.get("result", {})
        servers = result.get("servers", [])
        peers: List[Peer] = []
        for server in servers:
            host = str(server.get("host", seed.host))
            port = int(server.get("port", seed.port))
            node_id = server.get("node_id")
            if host in {"0.0.0.0", "::"}:
                host = seed.host
            if node_id is None:
                continue
            peers.append(Peer(int(node_id), host, port))
        return peers
    except Exception:
        return []


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Jogo distribuido com RPC, Lamport, eleicao Bully, "
            "replicacao versionada e failover."
        )
    )
    subparsers = parser.add_subparsers(dest="mode", required=True)

    for command in ("server", "node"):
        node_parser = subparsers.add_parser(command, help="executa um no servidor distribuido")
        node_parser.add_argument("--id", type=int, default=None, help="identificador numerico do no (auto se omitido)")
        node_parser.add_argument("--host", default="0.0.0.0", help="host de escuta (default 0.0.0.0)")
        node_parser.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"porta do RPC (default {DEFAULT_PORT})")
        node_parser.add_argument(
            "--peer",
            action="append",
            default=[],
            type=parse_peer,
            help="outro no no formato host:porta ou id:host:porta. Pode ser usado varias vezes.",
        )

    client_parser = subparsers.add_parser("client", help="executa o cliente grafico Pygame")
    client_parser.add_argument("--player", default=f"player-{random.randint(100, 999)}", help="nome do jogador")
    client_parser.add_argument(
        "--server",
        type=parse_host_port,
        default=("127.0.0.1", DEFAULT_PORT),
        help=f"host:porta inicial (default 127.0.0.1:{DEFAULT_PORT})",
    )

    local_parser = subparsers.add_parser("local", help="executa apenas a fisica local, sem rede")
    local_parser.add_argument("--player", default="local", help="nome do jogador")

    status_parser = subparsers.add_parser(
        "status", help="consulta estado, replicas e metricas de um no"
    )
    status_parser.add_argument(
        "--server",
        type=parse_host_port,
        default=("127.0.0.1", DEFAULT_PORT),
        help=f"host:porta do no (default 127.0.0.1:{DEFAULT_PORT})",
    )
    status_parser.add_argument("--timeout", type=float, default=1.0)

    return parser


def resolve_peers(seeds: List[Peer]) -> List[Peer]:
    resolved: Dict[int, Peer] = {}
    pending: List[Peer] = []
    for peer in seeds:
        if peer.node_id > 0:
            resolved[peer.node_id] = peer
        else:
            pending.append(peer)

    for peer in pending:
        node_id = discover_peer_id(peer.host, peer.port)
        if node_id is None:
            print(f"[setup] aviso: nao foi possivel descobrir id do peer {peer.host}:{peer.port}; pulando")
            continue
        resolved[node_id] = Peer(node_id, peer.host, peer.port)

    for seed in list(resolved.values()):
        for discovered in discover_cluster(seed):
            resolved.setdefault(discovered.node_id, discovered)

    return list(resolved.values())


def main() -> None:
    args = build_parser().parse_args()
    if args.mode in ("node", "server"):
        peers = resolve_peers(args.peer)
        used_ids = {peer.node_id for peer in peers}
        node_id = args.id
        if node_id is None:
            candidate = random.randint(1, 999)
            while candidate in used_ids:
                candidate = random.randint(1, 999)
            node_id = candidate
            print(f"[setup] id auto-gerado: {node_id}")
        peers = [peer for peer in peers if peer.node_id != node_id]
        if peers:
            print(f"[setup] cluster: {[(p.node_id, p.host, p.port) for p in peers]}")
        node = DistributedGameNode(node_id, args.host, args.port, peers)
        asyncio.run(node.start())
    elif args.mode == "client":
        host, port = args.server
        run_client(args.player, host, port)
    elif args.mode == "local":
        run_local(args.player)
    elif args.mode == "status":
        host, port = args.server
        response = sync_rpc_call(
            host,
            port,
            "status-cli",
            "status",
            {},
            timeout=args.timeout,
        )
        print(json.dumps(response.get("result", {}), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
