
# SonarLint — Configuração rápida (VS Code / IntelliJ)

## VS Code
1. Abra o VS Code.
2. Extensions → procure por `SonarLint` → Install.
3. Abra o projeto.
4. Abra um arquivo .js/.py/.java — o SonarLint já deve começar a analisar.
5. (Opcional) Connected Mode:
   - Abra o painel do SonarLint.
   - Configure a conexão com SonarCloud (OAuth) e vincule ao projeto.

## IntelliJ / JetBrains
1. File > Settings > Plugins → Marketplace → `SonarLint` → Install.
2. Restart IDE se necessário.
3. Tools > SonarLint > Bind to SonarQube/SonarCloud (para Connected Mode) e siga os passos.
