# books.py
import time
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse, JSONResponse
import httpx
import os
import asyncio

router = APIRouter(prefix="/api/books", tags=["books"])

GOOGLE_BOOKS_BASE = "https://www.googleapis.com/books/v1"
# opcional: você pode definir sua API KEY no env var GOOGLE_BOOKS_KEY
GOOGLE_BOOKS_KEY = os.environ.get("GOOGLE_BOOKS_KEY", None)

# caches simples em memória com TTL
_CACHE_TTL = 60 * 60  # 1 hora
_search_cache: Dict[str, Dict[str, Any]] = {}
_volume_cache: Dict[str, Dict[str, Any]] = {}
_image_cache: Dict[str, Dict[str, Any]] = {}

# util helpers
def _now() -> float:
    return time.time()

def _is_valid_cache(entry: Dict[str, Any]) -> bool:
    return entry and ("ts" in entry) and (_now() - entry["ts"] < _CACHE_TTL)

def _cache_set(cache: Dict, key: str, value: Any):
    cache[key] = {"ts": _now(), "value": value}

async def _http_get_json(url: str, params: dict = None, timeout: float = 10.0) -> dict:
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

async def _http_get_stream(url: str, timeout: float = 20.0) -> httpx.Response:
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        return resp

def _map_volume_item(item: dict) -> dict:
    """Extrai campos relevantes do item retornado pelo Google Books"""
    vol_info = item.get("volumeInfo", {})
    image_links = vol_info.get("imageLinks", {}) or {}
    thumbnail = image_links.get("thumbnail") or image_links.get("smallThumbnail")
    return {
        "id": item.get("id"),
        "title": vol_info.get("title"),
        "subtitle": vol_info.get("subtitle"),
        "authors": vol_info.get("authors") or [],
        "publisher": vol_info.get("publisher"),
        "publishedDate": vol_info.get("publishedDate"),
        "description": vol_info.get("description"),
        "pageCount": vol_info.get("pageCount"),
        "categories": vol_info.get("categories") or [],
        "averageRating": vol_info.get("averageRating"),
        "ratingsCount": vol_info.get("ratingsCount"),
        "language": vol_info.get("language"),
        "previewLink": vol_info.get("previewLink"),
        "infoLink": vol_info.get("infoLink"),
        "thumbnail": thumbnail,
    }

# -----------------
# ROUTES
# -----------------

@router.get("/search")
async def search_books(q: str = Query(..., min_length=1), max: int = Query(10, ge=1, le=40)):
    """
    Busca livros via Google Books.
    Parâmetros:
      - q: termo de busca (título, autor, isbn, etc)
      - max: número máximo de resultados (default 10, max 40)
    """
    cache_key = f"search::{q}::max={max}"
    if cache_key in _search_cache and _is_valid_cache(_search_cache[cache_key]):
        return JSONResponse(content=_search_cache[cache_key]["value"])

    params = {"q": q, "maxResults": max}
    if GOOGLE_BOOKS_KEY:
        params["key"] = GOOGLE_BOOKS_KEY

    url = f"{GOOGLE_BOOKS_BASE}/volumes"
    try:
        data = await _http_get_json(url, params=params)
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail="Erro ao consultar Google Books")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")

    items = data.get("items") or []
    mapped = [_map_volume_item(it) for it in items]

    payload = {
        "totalItems": data.get("totalItems", 0),
        "items": mapped
    }

    _cache_set(_search_cache, cache_key, payload)
    return JSONResponse(content=payload)


@router.get("/{volume_id}")
async def get_volume(volume_id: str):
    """
    Retorna detalhe de um volume específico.
    """
    cache_key = f"volume::{volume_id}"
    if cache_key in _volume_cache and _is_valid_cache(_volume_cache[cache_key]):
        return JSONResponse(content=_volume_cache[cache_key]["value"])

    url = f"{GOOGLE_BOOKS_BASE}/volumes/{volume_id}"
    params = {}
    if GOOGLE_BOOKS_KEY:
        params["key"] = GOOGLE_BOOKS_KEY

    try:
        data = await _http_get_json(url, params=params)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise HTTPException(status_code=404, detail="Volume não encontrado")
        raise HTTPException(status_code=e.response.status_code, detail="Erro ao consultar Google Books")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")

    mapped = _map_volume_item(data)
    _cache_set(_volume_cache, cache_key, mapped)
    return JSONResponse(content=mapped)


@router.get("/thumbnail/{volume_id}")
async def proxy_thumbnail(volume_id: str):
    """
    Proxy da thumbnail: busca a informação do volume e faz GET da imagem retornando o conteúdo.
    Se não houver thumbnail, retorna 404.
    """
    # busca o detalhe (usa cache se disponível)
    cache_key = f"volume::{volume_id}"
    volume = None
    if cache_key in _volume_cache and _is_valid_cache(_volume_cache[cache_key]):
        volume = _volume_cache[cache_key]["value"]
    else:
        url = f"{GOOGLE_BOOKS_BASE}/volumes/{volume_id}"
        params = {}
        if GOOGLE_BOOKS_KEY:
            params["key"] = GOOGLE_BOOKS_KEY
        try:
            data = await _http_get_json(url, params=params)
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                raise HTTPException(status_code=404, detail="Volume não encontrado")
            raise HTTPException(status_code=e.response.status_code, detail="Erro ao consultar Google Books")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")
        volume = _map_volume_item(data)
        _cache_set(_volume_cache, cache_key, volume)

    thumbnail_url = volume.get("thumbnail")
    if not thumbnail_url:
        raise HTTPException(status_code=404, detail="Thumbnail não encontrada para este volume")

    # se já está em cache de imagens e válido, retorna do cache
    img_cache_key = f"img::{thumbnail_url}"
    if img_cache_key in _image_cache and _is_valid_cache(_image_cache[img_cache_key]):
        cached = _image_cache[img_cache_key]["value"]
        return StreamingResponse(cached["body"], media_type=cached["content_type"])

    # buscar imagem externa
    try:
        resp = await _http_get_stream(thumbnail_url)
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=502, detail="Não foi possível recuperar a imagem externa")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao buscar imagem: {str(e)}")

    content_type = resp.headers.get("content-type", "image/jpeg")
    body = resp.content  # bytes

    # armazenar no cache (guardando bytes) - cuidado com memória, TTL curto
    _cache_set(_image_cache, img_cache_key, {"content_type": content_type, "body": body})

    # devolver stream
    return StreamingResponse(iter([body]), media_type=content_type)
