// app.js - Versão Final: Imagens Corrigidas + Grade Paginada + Auth

document.addEventListener('DOMContentLoaded', () => {

  /* =========================
     CONFIG
     ========================= */
  const PATHS = {
    LOGIN: 'outras telas/login/login.html',
    REGISTER: 'outras telas/registrar/registro.html',
    PROFILE: '/profile',
    DASHBOARD: '/dashboard',
    HISTORY: '/history',
    FAVORITES: '/favorites'
  };

  // Ajuste: endpoint local (ajuste conforme seu backend)
  const API_BASE_URL = 'http://localhost:4000/api/books/search?q=tecnologia&max=40';

  const CATEGORIES = ['All','Ficção','Ciência','Programação','Negócios','Finanças','Educação'];

  /* =========================
     STATE
     ========================= */
  /* =========================
   STATE
   ========================= */
let booksData = [];
let currentPage = 1;

// MUDE AQUI: De 12 para 18
  const ITEMS_PER_PAGE = 18; // Agora vai mostrar 3 linhas cheias antes da paginação

  let isExpanded = false;
  const PREVIEW_COUNT = 8;   // mostra 8 itens no modo fechado
 

  /* =========================
     SELECTORES
     ========================= */
  const carousel = document.getElementById('carousel');
  const seeAllBtn = document.getElementById('seeAllBtn');
  const categoryList = document.getElementById('categoryList');
  const sidepanel = document.getElementById('sidepanel');
  const overlay = document.getElementById('overlay');
  const closeBtn = document.getElementById('closePanel');
  const btnReserve = document.getElementById('btnReserve');
  const btnLoan = document.getElementById('btnLoan');
  const searchInput = document.getElementById('searchInput');
  const mainContent = document.getElementById('mainContent');
  const paginationContainer = document.getElementById('paginationContainer');

  const avatarBtn = document.getElementById('avatarBtn');
  const profileArea = document.getElementById('profileArea');
  const userDropdown = document.getElementById('userDropdown');
  const notifBtn = document.getElementById('notifBtn');
  const notifBadge = document.getElementById('notifBadge');
  const sideNav = document.getElementById('sideNav');
  const sidebarFooter = document.getElementById('sidebarFooter');

  /* =========================
     SESSION (mock)
     ========================= */
  let currentUser = null;
  let isLogged = false;
  (function loadSession(){
    try {
      currentUser = JSON.parse(localStorage.getItem('BIB_USER'));
      isLogged = !!localStorage.getItem('BIB_TOKEN');
    } catch { currentUser = null; isLogged = false; }
  })();

  /* =========================
     HELPERS
     ========================= */
  function generateRandomPastelColor() {
    const colors = ["#f7e7d7", "#d7f7e9", "#d7e7ff", "#fff2d7", "#f0d7ff", "#e2f0cb", "#ffdfd3"];
    return colors[Math.floor(Math.random() * colors.length)];
  }
  function firstName(fullName){ if(!fullName) return ''; return fullName.trim().split(/\s+/)[0]; }
  function escapeHtml(str){ if(!str) return ''; return String(str).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;'); }

  /* =========================
     FETCH BOOKS
     ========================= */
  async function fetchBooks(){
    if(!carousel) return;
    carousel.innerHTML = '<div style="padding:20px;">Carregando biblioteca...</div>';
    try {
      const res = await fetch(API_BASE_URL);
      if(!res.ok) throw new Error(`Erro API ${res.status}`);
      const data = await res.json();
      const items = data.items || data || [];

      // adapta para o formato esperado (o backend/python já pode retornar simplificado)
      allBooks = items.map(i => {
        // se já veio com os campos esperados, usa direto
        if(i.title && (i.thumbnail || i.color || i.id)) {
          return {
            id: i.id || Math.random().toString(36).slice(2,9),
            title: i.title,
            author: Array.isArray(i.authors) ? i.authors[0] : (i.author || i.authors || 'Autor Desconhecido'),
            category: Array.isArray(i.categories) ? i.categories[0] : (i.category || 'Geral'),
            pages: i.pageCount || i.pages || 0,
            rating: i.averageRating || i.rating || 0,
            available: i.available || 5,
            desc: i.description || i.desc || '',
            color: i.color || generateRandomPastelColor(),
            thumbnail: i.thumbnail || i.image || i.imageLinks?.thumbnail || null
          };
        }
        // fallback generico (caso o formato seja diferente)
        const info = i.volumeInfo || i;
        return {
          id: i.id || info.id || Math.random().toString(36).slice(2,9),
          title: info.title || 'Sem Título',
          author: (info.authors && info.authors[0]) || info.author || 'Autor Desconhecido',
          category: (info.categories && info.categories[0]) || 'Geral',
          pages: info.pageCount || 0,
          rating: info.averageRating || 0,
          available: 5,
          desc: info.description || '',
          color: generateRandomPastelColor(),
          thumbnail: info.imageLinks?.thumbnail || info.thumbnail || null
        };
      });

      // inicializa filtro (sem filtro = todos)
      filteredBooks = allBooks.slice();
      currentPage = 1;
      renderCategoryPills(0);
      updateView();
    } catch(err){
      console.error(err);
      carousel.innerHTML = `<div style="padding:20px;color:#d9534f;">Erro ao carregar: ${escapeHtml(err.message)}</div>`;
    }
  }

  /* =========================
     RENDER / UPDATE VIEW
     ========================= */
  function updateView(){
    carousel.innerHTML = '';
    paginationContainer.innerHTML = '';

    if(!filteredBooks || filteredBooks.length === 0){
      carousel.innerHTML = '<div style="padding:20px;">Nenhum livro encontrado.</div>';
      return;
    }

    let itemsToShow = [];

    if(!isExpanded){
      // preview mode: mostra apenas PREVIEW_COUNT
      itemsToShow = filteredBooks.slice(0, PREVIEW_COUNT);
      paginationContainer.style.display = 'none';
      if(seeAllBtn) { seeAllBtn.textContent = 'See All'; seeAllBtn.setAttribute('aria-expanded','false'); }
    } else {
      // expanded mode: pagina com ITEMS_PER_PAGE
      const start = (currentPage - 1) * ITEMS_PER_PAGE;
      itemsToShow = filteredBooks.slice(start, start + ITEMS_PER_PAGE);
      paginationContainer.style.display = 'flex';
      if(seeAllBtn) { seeAllBtn.textContent = 'Show Less'; seeAllBtn.setAttribute('aria-expanded','true'); }
      renderPaginationButtons();
    }

    // cria cards (com thumbnail quando disponível)
    itemsToShow.forEach(book => {
      const card = document.createElement('div');
      card.className = 'card-item';
      card.setAttribute('role','listitem');

      let coverHTML = '';
      if(book.thumbnail){
        const safe = String(book.thumbnail).replace(/^http:\/\//i, 'https://');
        coverHTML = `<div class="book-cover"><img src="${safe}" alt="${escapeHtml(book.title)}" style="width:100%;height:100%;object-fit:cover;display:block" loading="lazy" onerror="this.style.display='none'; this.parentElement.style.background='${book.color}'; this.parentElement.textContent='${escapeHtml((book.title||'').slice(0,3).toUpperCase())}'"></div>`;
      } else {
        const initials = escapeHtml((book.title||'').split(' ')[0].slice(0,3).toUpperCase());
        coverHTML = `<div class="book-cover" style="background:${book.color};display:flex;align-items:center;justify-content:center">${initials}</div>`;
      }

      card.innerHTML = `
        ${coverHTML}
        <div class="book-title">${escapeHtml(book.title)}</div>
        <div class="book-author">${escapeHtml(book.author)}</div>
      `;
      card.addEventListener('click', () => openPanel(book));
      carousel.appendChild(card);
    });
  }

  function renderPaginationButtons(){
    paginationContainer.innerHTML = '';
    const totalPages = Math.max(1, Math.ceil(filteredBooks.length / ITEMS_PER_PAGE));
    for(let i=1;i<=totalPages;i++){
      const btn = document.createElement('button');
      btn.className = 'page-btn' + (i===currentPage ? ' active' : '');
      btn.textContent = i;
      btn.addEventListener('click', () => {
        currentPage = i;
        updateView();
        document.getElementById('rec-title')?.scrollIntoView({behavior:'smooth'});
      });
      paginationContainer.appendChild(btn);
    }
  }

  /* =========================
     SEARCH & CATEGORY FILTER
     ========================= */
  function applyFilters(){
    const q = (searchInput?.value || '').trim().toLowerCase();
    // selected category
    const activeCatBtn = categoryList?.querySelector('.cat.active');
    const cat = activeCatBtn ? activeCatBtn.textContent.trim() : 'All';

    filteredBooks = allBooks.filter(b => {
      const matchQ = !q || (`${b.title} ${b.author} ${b.category}`).toLowerCase().includes(q);
      const matchCat = (cat === 'All') || (b.category && b.category.toLowerCase().includes(cat.toLowerCase()));
      return matchQ && matchCat;
    });

    currentPage = 1;
    updateView();
  }

  (function attachSearch(){
    if(!searchInput) return;
    let t = null;
    searchInput.addEventListener('input', () => {
      clearTimeout(t);
      t = setTimeout(() => applyFilters(), 160); // debounce pequeno
    });
  })();

  function renderCategoryPills(activeIndex = 0){
    if(!categoryList) return;
    categoryList.innerHTML = '';
    CATEGORIES.forEach((cat, i) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'cat' + (i === activeIndex ? ' active' : '');
      btn.textContent = cat;
      btn.addEventListener('click', () => {
        categoryList.querySelectorAll('.cat').forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        applyFilters();
      });
      categoryList.appendChild(btn);
    });
  }

  /* =========================
     SIDE PANEL
     ========================= */
  function openPanel(book){
    document.getElementById('sideTitle').textContent = book.title;
    document.getElementById('sideAuthor').textContent = book.author;
    document.getElementById('sideDesc').textContent = book.desc;
    document.getElementById('sidePages').textContent = book.pages;
    document.getElementById('sideRating').textContent = book.rating;
    document.getElementById('sideAvailability').textContent = book.available;
    const coverEl = document.getElementById('sideCover');
    if(book.thumbnail){ coverEl.style.background = `url('${book.thumbnail.replace(/^http:\/\//i,'https://')}') center/cover no-repeat`; }
    else { coverEl.style.background = book.color; }
    sidepanel.classList.add('visible');
    overlay.classList.add('visible');
    sidepanel.setAttribute('aria-hidden','false');
    mainContent.classList.add('panel-open');
    sidepanel.dataset.bookId = book.id;
  }
  function closePanel(){
    sidepanel.classList.remove('visible');
    overlay.classList.remove('visible');
    sidepanel.setAttribute('aria-hidden','true');
    mainContent.classList.remove('panel-open');
    delete sidepanel.dataset.bookId;
  }

  /* =========================
     UI EVENTS
     ========================= */
  // See All toggle
  seeAllBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    isExpanded = !isExpanded;
    // reset page when expand
    if(isExpanded) currentPage = 1;
    updateView();
    // scroll to top of section when expanding
    if(isExpanded) document.getElementById('rec-title')?.scrollIntoView({behavior:'smooth'});
  });

  // overlay/panel
  overlay?.addEventListener('click', closePanel);
  closeBtn?.addEventListener('click', closePanel);
  document.addEventListener('keydown', e => { if(e.key === 'Escape') closePanel(); });

  // reserve/read actions
  btnReserve?.addEventListener('click', ()=> alert('Reserva solicitada!'));
  btnLoan?.addEventListener('click', ()=> alert('Empréstimo iniciado!'));

  // notifications & avatar
  notifBtn?.addEventListener('click', (e)=>{ e.stopPropagation(); alert('Sem notificações.'); });
  if(notifBadge) notifBadge.textContent = '3';

  // dropdown (mock)
  let caretEl = null;
  (function ensureCaret(){
    if(!profileArea) return;
    caretEl = profileArea.querySelector('.caret');
    if(!caretEl){
      caretEl = document.createElement('span');
      caretEl.className = 'caret';
      caretEl.innerHTML = '<i class="fa-solid fa-chevron-down"></i>';
      const nameNode = profileArea.querySelector('.name');
      if(nameNode && nameNode.parentNode) nameNode.parentNode.insertBefore(caretEl, nameNode.nextSibling);
      else profileArea.appendChild(caretEl);
    }
  })();

  function toggleDropdown(e){
    if(!isLogged) return window.location.href = PATHS.LOGIN;
    e.stopPropagation();
    userDropdown.classList.toggle('show');
    if(caretEl) caretEl.classList.toggle('open', userDropdown.classList.contains('show'));
  }

  avatarBtn?.addEventListener('click', toggleDropdown);
  profileArea?.querySelector('.name')?.addEventListener('click', toggleDropdown);
  document.addEventListener('click', (e) => {
    if(userDropdown && !userDropdown.contains(e.target) && !profileArea.contains(e.target)){
      userDropdown.classList.remove('show');
      if(caretEl) caretEl.classList.remove('open');
    }
  });

  /* =========================
     MENU / AUTH (mock)
     ========================= */
  const ITEMS_LOGGED_OUT = [
    { key:'discover', label:'Descubra', icon:'fa-solid fa-house' , href:'#' },
    { key:'categories', label:'Categorias', icon:'fa-solid fa-book-open', href:'#' },
    { key:'audio', label:'Audio Books', icon:'fa-solid fa-headphones', href:'#' },
    { key:'support', label:'Suporte', icon:'fa-regular fa-life-ring', href:'#' },
  ];
  const ITEMS_LOGGED_IN = [
    { key:'discover', label:'Descubra', icon:'fa-solid fa-house', href:'#' },
    { key:'categories', label:'Categorias', icon:'fa-regular fa-folder', href:'#' },
    { key:'library', label:'My Library', icon:'fa-regular fa-folder-open', href:'#' },
    { key:'downloads', label:'Downloads', icon:'fa-solid fa-download', href:'#' },
    { key:'audio', label:'Audio Books', icon:'fa-solid fa-headphones', href:'#' },
    { key:'favs', label:'Favoritos', icon:'fa-regular fa-heart', href:'#' },
    { key:'separator' },
    { key:'settings', label:'Settings', icon:'fa-solid fa-gear', href:'#' },
    { key:'logout', label:'Logout', icon:'fa-solid fa-right-from-bracket', href:'#' }
  ];

  function makeNavItem(item){
    const a = document.createElement('a');
    a.className = 'nav-item';
    a.href = item.href || '#';
    a.dataset.key = item.key;
    a.innerHTML = `<span class="nav-icon"><i class="${item.icon}"></i></span><span class="nav-label">${item.label}</span>`;
    a.addEventListener('click', (e)=>{
      if(item.key === 'logout'){ e.preventDefault(); handleLogout(); return; }
      e.preventDefault();
      document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
      a.classList.add('active');
      if(item.key === 'discover'){ isExpanded = false; currentPage = 1; updateView(); mainContent.scrollTo({top:0,behavior:'smooth'}) }
    });
    return a;
  }

  function renderMenu(){
    sideNav.innerHTML = '';
    const list = isLogged ? ITEMS_LOGGED_IN : ITEMS_LOGGED_OUT;
    list.forEach(it => {
      if(it.key === 'separator'){ const sep = document.createElement('div'); sep.className='menu-separator'; sideNav.appendChild(sep); return; }
      sideNav.appendChild(makeNavItem(it));
    });
    if(sidebarFooter){
      if(isLogged) sidebarFooter.style.display = 'none';
      else {
        sidebarFooter.style.display = 'flex';
        document.getElementById('loginBtn').onclick = ()=> window.location.href = PATHS.LOGIN;
        document.getElementById('registerBtn').onclick = ()=> window.location.href = PATHS.REGISTER;
      }
    }
  }

  function handleLogout(){
    localStorage.removeItem('BIB_TOKEN'); localStorage.removeItem('BIB_USER'); currentUser = null; isLogged = false;
    renderMenu(); applyLoggedOutUI(); buildUserDropdown();
  }
  function applyLoggedOutUI(){
    avatarBtn.classList.add('logged-out'); avatarBtn.innerHTML = `<i class="fa-regular fa-user"></i>`;
    profileArea.querySelector('.name').textContent = 'Login';
    if(caretEl) caretEl.style.display = 'none';
    profileArea.onclick = () => window.location.href = PATHS.LOGIN;
  }
  function applyLoggedInUI(){
    avatarBtn.classList.remove('logged-out'); let n = (currentUser && currentUser.name) || 'User'; avatarBtn.textContent = n.charAt(0).toUpperCase();
    profileArea.querySelector('.name').textContent = firstName(n); if(caretEl) caretEl.style.display = '';
    profileArea.onclick = null; buildUserDropdown();
  }
  function buildUserDropdown(){
    if(!userDropdown) return;
    userDropdown.innerHTML = '';
    if(!isLogged) return;
    const add = (txt, url) => { const a = document.createElement('a'); a.className='dropdown-item'; a.textContent=txt; a.href=url; userDropdown.appendChild(a); };
    add('Perfil', PATHS.PROFILE); add('Sair', '#');
    userDropdown.lastChild.onclick = (e) => { e.preventDefault(); handleLogout(); };
  }

  /* =========================
     INITIALIZE
     ========================= */
  renderMenu();
  renderCategoryPills(0);
  if(isLogged) applyLoggedInUI(); else applyLoggedOutUI();
  fetchBooks();

});
